import { createFileRoute } from "@tanstack/react-router";
import { JobBoard } from "@/components/job-board";

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  return <JobBoard />;
}
