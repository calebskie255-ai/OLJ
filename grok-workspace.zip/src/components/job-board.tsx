import { useMemo, useState } from "react";
import { format, parse } from "date-fns";
import { ArrowUpRight, Radar, RefreshCw, Search } from "lucide-react";
import rawBoard from "@/data/board.json";
import { payRank, type Job, type Lane } from "@/lib/jobs/filter";
import { rescanJobs } from "@/lib/jobs/scan";

type BoardFile = {
  scannedAt: string;
  source: string;
  read: number;
  kept: number;
  stripped: {
    coldCallDataEntry: number;
    basic: number;
    offLane: number;
  };
  jobs: Job[];
};

const board = rawBoard as BoardFile;

type LaneFilter = "all" | Lane | "both";
type SortKey = "newest" | "pay";

const LANES: Array<{ id: LaneFilter; label: string }> = [
  { id: "all", label: "All builds" },
  { id: "ghl", label: "GHL builds" },
  { id: "ai", label: "AI automation" },
  { id: "both", label: "Both" },
];

const TYPES = ["All types", "Full Time", "Part Time", "Gig", "Any"] as const;

const STACKS = ["Any stack", "GoHighLevel", "n8n", "Make", "Zapier", "Voice AI"] as const;

function tidySnippet(value: string): string {
  return value.replace(/\s*see more\s*$/i, "").trim();
}

function tidyTitle(title: string): string {
  return title
    .replace(/^#\s*/, "")
    .replace(/^job title:\s*/i, "")
    .replace(/^oice AI/i, "Voice AI");
}

function formatPosted(value: string): string {
  const day = value.slice(0, 10);
  const parsed = parse(day, "yyyy-MM-dd", new Date(2026, 0, 1));
  if (Number.isNaN(parsed.getTime())) return value;
  return format(parsed, "d MMM yyyy");
}

function laneLabel(lane: Lane): string {
  return lane === "ghl" ? "GHL build" : "AI automation";
}

function why(job: Job): string {
  if (job.lanes.length === 2) {
    return "GoHighLevel system build that also ships AI automation.";
  }
  if (job.lanes.includes("ghl")) {
    return "GoHighLevel build — funnels, workflows, snapshots, or sub-accounts.";
  }
  return "AI automation build — agents, voice, or workflow systems.";
}

function mergeJobs(current: Job[], incoming: Job[]): Job[] {
  const map = new Map(current.map((job) => [job.id, job]));
  for (const job of incoming) map.set(job.id, job);
  return [...map.values()].sort((a, b) => b.posted.localeCompare(a.posted));
}

export function JobBoard() {
  const [jobs, setJobs] = useState<Job[]>(board.jobs);
  const [query, setQuery] = useState("");
  const [lane, setLane] = useState<LaneFilter>("all");
  const [type, setType] = useState<(typeof TYPES)[number]>("All types");
  const [stack, setStack] = useState<(typeof STACKS)[number]>("Any stack");
  const [sort, setSort] = useState<SortKey>("newest");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [scanning, setScanning] = useState(false);
  const [note, setNote] = useState(
    `Saved scan of ${board.source}, 9 Nov 2026. ${board.read} posts read, ${board.kept} kept.`,
  );

  const visible = useMemo(() => {
    const needle = query.trim().toLowerCase();
    const next = jobs.filter((job) => {
      if (lane === "both" && job.lanes.length < 2) return false;
      if (lane === "ghl" && !job.lanes.includes("ghl")) return false;
      if (lane === "ai" && !job.lanes.includes("ai")) return false;
      if (type !== "All types" && job.type !== type) return false;
      if (stack !== "Any stack" && !job.stacks.includes(stack)) return false;
      if (!needle) return true;
      const hay = `${job.title} ${job.snippet} ${job.stacks.join(" ")} ${job.pay}`.toLowerCase();
      return hay.includes(needle);
    });
    next.sort((a, b) => {
      if (sort === "pay") return payRank(b.pay) - payRank(a.pay);
      return b.posted.localeCompare(a.posted);
    });
    return next;
  }, [jobs, query, lane, type, stack, sort]);

  const selected = visible.find((job) => job.id === selectedId) ?? null;
  const stripped = board.stripped.coldCallDataEntry + board.stripped.basic;

  async function rescan() {
    setScanning(true);
    try {
      const result = await rescanJobs();
      if (result.jobs.length) {
        setJobs((current) => mergeJobs(current, result.jobs));
      }
      setNote(result.message);
    } catch {
      setNote("Live scan failed. The saved OnlineJobs.ph pull is still here.");
    } finally {
      setScanning(false);
    }
  }

  return (
    <main className="min-h-screen bg-bg text-fg">
      <div className="mx-auto flex w-full min-w-0 max-w-6xl flex-col gap-6 px-4 py-6 sm:px-6 sm:py-8">
        <header className="flex flex-col gap-5 border-b border-border pb-6">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div className="flex items-start gap-3">
              <span className="mt-1 flex h-11 w-11 items-center justify-center rounded-lg bg-primary text-primary-fg">
                <Radar className="h-5 w-5" aria-hidden />
              </span>
              <div>
                <p className="font-mono text-xs tracking-widest text-primary uppercase">
                  OnlineJobs.ph
                </p>
                <h1 className="text-3xl font-semibold tracking-tight">Forge</h1>
                <p className="mt-1 max-w-xl text-sm leading-relaxed text-muted">
                  GoHighLevel builds and AI automation only. Cold calling, data
                  entry, appointment setting, and basic VA work never make this list.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={rescan}
              disabled={scanning}
              className="inline-flex h-11 items-center gap-2 rounded-lg bg-primary px-4 text-sm font-semibold text-primary-fg disabled:opacity-60"
            >
              <RefreshCw className={`h-4 w-4 ${scanning ? "animate-spin" : ""}`} aria-hidden />
              {scanning ? "Scanning" : "Rescan"}
            </button>
          </div>
          <dl className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Stat label="Posts read" value={String(board.read)} />
            <Stat label="Builder roles" value={String(jobs.length)} />
            <Stat label="Cold call / data / VA" value={String(stripped)} hint="stripped" />
            <Stat label="Off the lane" value={String(board.stripped.offLane)} hint="not a build" />
          </dl>
          <p className="font-mono text-xs leading-relaxed text-muted">{note}</p>
        </header>

        <div className="flex flex-col gap-3">
          <label className="relative block">
            <span className="sr-only">Search roles</span>
            <Search
              className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted"
              aria-hidden
            />
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Search title, stack, or pay"
              className="h-11 w-full rounded-lg border border-border bg-surface pr-3 pl-10 text-sm text-fg outline-none placeholder:text-muted focus:border-primary"
            />
          </label>
          <div className="flex flex-wrap gap-2">
            {LANES.map((item) => (
              <Chip
                key={item.id}
                active={lane === item.id}
                onClick={() => setLane(item.id)}
                label={item.label}
              />
            ))}
          </div>
          <div className="flex flex-wrap gap-2">
            {TYPES.map((item) => (
              <Chip key={item} active={type === item} onClick={() => setType(item)} label={item} />
            ))}
            <Chip
              active={sort === "newest"}
              onClick={() => setSort("newest")}
              label="Newest"
            />
            <Chip
              active={sort === "pay"}
              onClick={() => setSort("pay")}
              label="Higher posted pay"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            {STACKS.map((item) => (
              <Chip key={item} active={stack === item} onClick={() => setStack(item)} label={item} />
            ))}
          </div>
          <p className="font-mono text-xs text-muted">
            Showing {visible.length} of {jobs.length}
          </p>
        </div>

        <div className="grid items-start gap-4 lg:grid-cols-3">
          <ul className="flex flex-col gap-3 lg:col-span-2">
            {visible.length === 0 ? (
              <li className="rounded-lg border border-border bg-surface px-4 py-8 text-sm text-muted">
                Nothing in this cut. Clear a filter or rescan OnlineJobs.ph.
              </li>
            ) : (
              visible.map((job) => (
                <li key={job.id}>
                  <article>
                    <button
                      type="button"
                      onClick={() =>
                        setSelectedId((current) => (current === job.id ? null : job.id))
                      }
                      aria-expanded={selected === job}
                      className={`lift w-full rounded-lg border px-4 py-4 text-left ${
                        selected?.id === job.id
                          ? "border-primary bg-surface-2"
                          : "border-border bg-surface"
                      }`}
                    >
                      <div className="flex flex-wrap items-center gap-2">
                        {job.lanes.map((item) => (
                          <LaneTag key={item} lane={item} />
                        ))}
                        {job.type ? (
                          <span className="font-mono text-xs text-muted">{job.type}</span>
                        ) : null}
                        <span className="ml-auto font-mono text-xs text-muted">
                          {formatPosted(job.posted)}
                        </span>
                      </div>
                      <h2 className="mt-2 text-lg leading-snug font-semibold">
                        {tidyTitle(job.title)}
                      </h2>
                      <p className="mt-2 font-mono text-sm text-primary">
                        {job.pay || "Pay not listed"}
                      </p>
                      <p className="mt-2 line-clamp-3 text-sm leading-relaxed text-muted">
                        {tidySnippet(job.snippet) || "Open the original post for the full brief."}
                      </p>
                      {job.stacks.length ? (
                        <p className="mt-3 font-mono text-xs text-muted">
                          {job.stacks.join(" · ")}
                        </p>
                      ) : null}
                    </button>
                    {selected?.id === job.id ? (
                      <div className="lg:hidden">
                        <Detail job={job} />
                      </div>
                    ) : null}
                  </article>
                </li>
              ))
            )}
          </ul>
          <aside className="hidden lg:sticky lg:top-4 lg:block">
            {selected ? (
              <Detail job={selected} />
            ) : (
              <div className="rounded-lg border border-border bg-surface px-4 py-6 text-sm leading-relaxed text-muted">
                Select a role. The brief is the OnlineJobs.ph snippet. Apply on
                the original post — Forge does not message employers.
              </div>
            )}
          </aside>
        </div>
      </div>
    </main>
  );
}

function Stat({
  label,
  value,
  hint,
}: {
  label: string;
  value: string;
  hint?: string;
}) {
  return (
    <div className="rounded-lg border border-border bg-surface px-3 py-3">
      <dt className="font-mono text-xs tracking-wide text-muted uppercase">{label}</dt>
      <dd className="mt-1 text-2xl font-semibold tracking-tight">{value}</dd>
      {hint ? <p className="font-mono text-xs text-muted">{hint}</p> : null}
    </div>
  );
}

function Chip({
  active,
  label,
  onClick,
}: {
  active: boolean;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={`h-11 rounded-lg border px-3 text-sm ${
        active
          ? "border-primary bg-primary text-primary-fg"
          : "border-border bg-surface text-fg"
      }`}
    >
      {label}
    </button>
  );
}

function LaneTag({ lane }: { lane: Lane }) {
  const filled = lane === "ghl";
  return (
    <span
      className={`rounded-md px-2 py-1 font-mono text-xs ${
        filled
          ? "bg-primary text-primary-fg"
          : "border border-primary text-primary"
      }`}
    >
      {laneLabel(lane)}
    </span>
  );
}

function Detail({ job }: { job: Job }) {
  return (
    <div className="mt-2 rounded-lg border border-border bg-surface-2 p-4 lg:mt-0">
      <p className="font-mono text-xs tracking-widest text-primary uppercase">Why it is here</p>
      <p className="mt-2 text-sm leading-relaxed">{why(job)}</p>
      <p className="mt-4 text-sm leading-relaxed text-muted">
        {tidySnippet(job.snippet) || "The search card did not include a description."}
      </p>
      <a
        href={job.url}
        target="_blank"
        rel="noreferrer"
        className="mt-4 inline-flex h-11 items-center gap-2 rounded-lg bg-primary px-4 text-sm font-semibold text-primary-fg"
      >
        Open on OnlineJobs.ph
        <ArrowUpRight className="h-4 w-4" aria-hidden />
      </a>
      <p className="mt-3 font-mono text-xs text-muted">
        A jobseeker login is required to apply. Pay is copied from the post.
      </p>
    </div>
  );
}
