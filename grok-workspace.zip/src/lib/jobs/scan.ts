import { createServerFn } from "@tanstack/react-start";
import { parseSearchHtml, screenListing, type Job } from "./filter";

const QUERIES = [
  "https://www.onlinejobs.ph/jobseekers/jobsearch?jobkeyword=gohighlevel&isFromJobsearchForm=1",
  "https://www.onlinejobs.ph/jobseekers/jobsearch/30?jobkeyword=gohighlevel&isFromJobsearchForm=1",
  "https://www.onlinejobs.ph/jobseekers/jobsearch?jobkeyword=n8n&isFromJobsearchForm=1",
  "https://www.onlinejobs.ph/jobseekers/jobsearch?jobkeyword=AI%20automation&isFromJobsearchForm=1",
  "https://www.onlinejobs.ph/jobseekers/jobsearch?skill_tags=24220&isFromJobsearchForm=1",
];

export type ScanResult = {
  ok: boolean;
  scannedAt: string;
  read: number;
  kept: number;
  jobs: Job[];
  message: string;
};

async function fetchPage(url: string): Promise<string> {
  const response = await fetch(url, {
    headers: {
      "user-agent":
        "Mozilla/5.0 (compatible; ForgeJobRadar/1.0; +https://www.onlinejobs.ph/)",
      accept: "text/html",
    },
    signal: AbortSignal.timeout(12000),
  });
  if (!response.ok) throw new Error(`OnlineJobs.ph returned ${response.status}`);
  return response.text();
}

export const rescanJobs = createServerFn({ method: "POST" }).handler(
  async (): Promise<ScanResult> => {
    const byId = new Map<string, Job>();
    let read = 0;
    let failures = 0;

    for (const url of QUERIES) {
      try {
        const html = await fetchPage(url);
        const cards = parseSearchHtml(html);
        read += cards.length;
        for (const card of cards) {
          const screened = screenListing(card);
          if (screened.job) byId.set(screened.job.id, screened.job);
        }
      } catch {
        failures += 1;
      }
    }

    const jobs = [...byId.values()].sort((a, b) =>
      b.posted.localeCompare(a.posted),
    );

    if (!jobs.length && failures === QUERIES.length) {
      return {
        ok: false,
        scannedAt: new Date().toISOString(),
        read,
        kept: 0,
        jobs: [],
        message: "OnlineJobs.ph did not respond. The saved scan is still on screen.",
      };
    }

    return {
      ok: true,
      scannedAt: new Date().toISOString(),
      read,
      kept: jobs.length,
      jobs,
      message:
        failures > 0
          ? `Live pass read ${read} posts. ${failures} search page${failures === 1 ? "" : "s"} failed.`
          : `Live pass read ${read} posts and kept ${jobs.length} builder roles.`,
    };
  },
);
