//#region node_modules/.nitro/vite/services/ssr/assets/filter-BeQQAM0I.js
var GHL = /(go\s*high\s*level|gohighlevel|highlevel|\bghl\b)/i;
var STACK = /(\bn8n\b|make\.com|integromat|\bzapier\b|\bvapi\b|\bretell\b|synthflow|voice\s*ai|conversation\s*ai|claude\s*code|closebot|assistable)/i;
var BUILD = /(workflow|funnel|automation|snapshot|sub-?account|pipeline|webhook|integration|\bcrm\b|architect|developer|engineer|builder|implement)/i;
var TECH_TITLE = /(developer|engineer|architect|builder|technician|implementer|implementation)/i;
var AI_TITLE = /(ai\s*automation|automation\s*(specialist|engineer|developer|architect|technician)|ai\s*(developer|engineer)|voice\s*ai|\bn8n\b|make\.com|zapier)/i;
var COLD_TITLE = /(cold\s*call|appointment\s*set|data\s*entry|\bsetters?\b|\bclosers?\b|outbound|lead\s*gen|lead\s*generation|\bdialer\b|sales\s*call|sales associate|sales team|sms sales|lead calling|inbound lead)/i;
var BASIC_TITLE = /(virtual assistant|personal assist|\bva\b|\bcanva\b|social media|youtube|faceless|coordinator|executive assistant|customer support|customer service|transcription|copy\s*paste|\binbox\b)/i;
var CALL_DUTY = /\b(data entry|cold call(?:ing|er)?|appointment setting|outbound calling|power dial)\b/i;
var STACK_TAGS = [
	[GHL, "GoHighLevel"],
	[/\bn8n\b/i, "n8n"],
	[/make\.com|integromat/i, "Make"],
	[/\bzapier\b/i, "Zapier"],
	[/\bvapi\b/i, "Vapi"],
	[/\bretell\b/i, "Retell"],
	[/synthflow/i, "Synthflow"],
	[/voice\s*ai|conversation\s*ai/i, "Voice AI"],
	[/claude/i, "Claude"],
	[/closebot|assistable/i, "AI chat"],
	[/\bpython\b/i, "Python"],
	[/webhook|\bapis?\b/i, "API"]
];
function extractStacks(text) {
	const found = [];
	for (const [pattern, label] of STACK_TAGS) if (pattern.test(text)) found.push(label);
	return found.slice(0, 5);
}
function decode(raw) {
	return raw.replace(/<br\s*\/?>/gi, "\n").replace(/<[^>]+>/g, " ").replace(/&/g, "&").replace(/&nbsp;|&#160;/g, " ").replace(/&#39;|'|&#x27;/g, "'").replace(/"/g, "\"").replace(/</g, "<").replace(/>/g, ">").replace(/&#(\d+);/g, (_, n) => {
		const code = Number(n);
		return Number.isFinite(code) ? String.fromCharCode(code) : "";
	}).replace(/\u00a0/g, " ").replace(/[ \t]+/g, " ").replace(/\n\s+/g, "\n").replace(/\s*See More\s*$/i, "").trim();
}
function screenListing(input) {
	const title = input.title.replace(/\s+/g, " ").trim();
	const snippet = input.snippet.replace(/\s+/g, " ").replace(/\s*see more\s*$/i, "").trim();
	const blob = `${title}\n${snippet}`;
	if (COLD_TITLE.test(title)) return {
		job: null,
		reason: "cold-or-data"
	};
	if (/\bseo\b/i.test(title) && !/(builder|developer|engineer|make\.com|\bn8n\b)/i.test(title)) return {
		job: null,
		reason: "basic"
	};
	if (/\boperator\b/i.test(title) && !/(n8n|gohighlevel|go high level|\bghl\b|technical operator)/i.test(title)) return {
		job: null,
		reason: "basic"
	};
	if (BASIC_TITLE.test(title) && !TECH_TITLE.test(title)) return {
		job: null,
		reason: "basic"
	};
	if (CALL_DUTY.test(snippet) && !TECH_TITLE.test(title) && !/voice\s*ai/i.test(title)) return {
		job: null,
		reason: "cold-or-data"
	};
	if (/circle program|webinar expert|tech support|marketing operations/i.test(title)) return {
		job: null,
		reason: "basic"
	};
	const ghl = GHL.test(blob);
	const stack = STACK.test(blob);
	const build = BUILD.test(blob);
	const lanes = [];
	const ghlTitle = GHL.test(title);
	const titleBuild = TECH_TITLE.test(title) || /(automation|funnel|workflow|systems|snapshot|crm|implement)/i.test(title);
	if (ghl && build && (ghlTitle || titleBuild) && !(/digital marketing specialist/i.test(title) && !/automation|developer|engineer/i.test(title))) lanes.push("ghl");
	if (AI_TITLE.test(title) && (stack || /\bai\b/i.test(blob)) && !/youtube|faceless|video editor/i.test(title)) lanes.push("ai");
	if (lanes.includes("ghl") && stack && !lanes.includes("ai")) {
		if (/(ai|n8n|voice|vapi|retell|make\.com|zapier|claude)/i.test(blob)) lanes.push("ai");
	}
	if (!lanes.length) return {
		job: null,
		reason: "off-lane"
	};
	const stacks = extractStacks(blob);
	return {
		job: {
			...input,
			title,
			snippet,
			lanes,
			stacks
		},
		reason: "kept"
	};
}
function parseSearchHtml(html) {
	const parts = html.split("class=\"jobpost-cat-box");
	const cards = [];
	for (const part of parts.slice(1)) {
		const heading = part.match(/<h4 class="fs-16 fw-700">([\s\S]*?)<\/h4>/);
		if (!heading) continue;
		const badge = heading[1].match(/<span class="badge[^"]*">([^<]+)<\/span>/);
		const title = decode(heading[1].replace(/<span class="badge[\s\S]*?<\/span>/, ""));
		const posted = (part.match(/Posted on ([0-9: -]+)/)?.[1] ?? "").trim();
		const pay = decode(part.match(/<dd class="col">([\s\S]*?)<\/dd>/)?.[1] ?? "");
		const snippet = decode(part.match(/<div class="desc[^"]*">([\s\S]*?)<\/div>/)?.[1] ?? "");
		const type = badge ? decode(badge[1]) : "";
		if (!title) continue;
		cards.push({
			title,
			posted,
			pay,
			snippet,
			type
		});
	}
	const links = [];
	const seen = /* @__PURE__ */ new Set();
	for (const match of html.matchAll(/href="(\/jobseekers\/job\/[^"]+)"/g)) {
		const path = match[1];
		if (seen.has(path)) continue;
		seen.add(path);
		links.push(path);
	}
	if (links.length < cards.length) return [];
	return cards.map((card, index) => {
		const path = links[index] ?? "";
		return {
			id: path.match(/(\d+)$/)?.[1] ?? path,
			title: card.title,
			url: path ? `https://www.onlinejobs.ph${path}` : "",
			pay: card.pay,
			type: card.type,
			posted: card.posted,
			snippet: card.snippet
		};
	}).filter((job) => job.id && job.url);
}
/** Rough monthly USD so the list can sort. Not shown as a conversion. */
function payRank(pay) {
	const source = pay.toLowerCase();
	const nums = [...source.matchAll(/\d[\d,]*(?:\.\d+)?/g)].map((match) => Number(match[0].replace(/,/g, ""))).filter((n) => Number.isFinite(n) && n > 0);
	if (!nums.length) return -1;
	let amount = nums[0] ?? -1;
	const hourly = /hour|\/hr|per hr|an hour|\/hour/.test(source);
	const php = /php|₱|peso/.test(source) || !hourly && amount >= 8e3;
	if (/aud/.test(source)) amount *= .66;
	if (php) amount /= 58;
	if (hourly) amount *= 160;
	return amount;
}
//#endregion
export { payRank as n, screenListing as r, parseSearchHtml as t };
