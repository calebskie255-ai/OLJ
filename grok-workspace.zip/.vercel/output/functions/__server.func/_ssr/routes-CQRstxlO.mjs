import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as ArrowUpRight, i as Radar, n as Search, r as RefreshCw } from "../_libs/lucide-react.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { n as payRank } from "./filter-BeQQAM0I.mjs";
import { n as format, t as parse } from "../_libs/date-fns.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CQRstxlO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var board_default = {
	scannedAt: "2026-11-09T13:20:00+08:00",
	source: "OnlineJobs.ph",
	read: 637,
	kept: 108,
	stripped: {
		"coldCallDataEntry": 127,
		"basic": 157,
		"offLane": 245
	},
	jobs: [
		{
			"id": "1756467",
			"title": "Tax CRM Automation & Website Specialist",
			"url": "https://www.onlinejobs.ph/jobseekers/job/tax-crm-automation-website-specialist-1756467",
			"pay": "770",
			"type": "Any",
			"posted": "2026-11-09 13:13:08",
			"snippet": "Builds GoHighLevel workflows, or Taxnitro websites, landing pages, funnels, onboarding systems, CRM pipelines, appointment scheduling, and email/SMS automations. Responsible for testing every workflow. See More",
			"lanes": ["ghl"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1763378",
			"title": "AI Automation Engineer (Full-Stack & AI Agent Developer)",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ai-automation-engineer-full-stack-ai-agent-developer-1763378",
			"pay": "Monthly rate in PHP based on experience",
			"type": "Any",
			"posted": "2026-11-09 11:38:36",
			"snippet": "Location: Remote Job Type: Part-time or Full-time, long-term Pay: Monthly rate in PHP, based on experience About Nextgen Pest Solutions Nextgen Pest Solutions is a veteran-owned pest control company protecting homes and businesses across Florida, Georgia, and Alabama. We run… See More",
			"lanes": ["ai"],
			"stacks": []
		},
		{
			"id": "1763274",
			"title": "AI Automation Specialist (Claude Code + Python) - Part-Time",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ai-automation-specialist-claude-code-python-part-time-1763274",
			"pay": "$375/month",
			"type": "Part Time",
			"posted": "2026-11-09 07:08:28",
			"snippet": "Remote · Part-Time · 20 hours per week, you set your own hours Mario Moosbauer · Growald Agency · Munich, Germany ABOUT US I'm Mario Moosbauer. I run Growald Agency, an AI agency specialising in e-commerce and Amazon, and Natureich,… See More",
			"lanes": ["ai"],
			"stacks": ["Claude", "Python"]
		},
		{
			"id": "1763251",
			"title": "Urgent Hiring! Junior Full Stack and Ai Developer",
			"url": "https://www.onlinejobs.ph/jobseekers/job/urgent-hiring-junior-full-stack-and-ai-developer-1763251",
			"pay": "90000",
			"type": "Full Time",
			"posted": "2026-11-09 05:52:26",
			"snippet": "Love Building with AI? Join Our Team! Solve Outsource Inc. is looking for a motivated junior developer who actively uses Claude Code or similar AI coding tools to build practical applications and automate workflows. You'll work on real business projects… See More",
			"lanes": ["ai"],
			"stacks": ["Claude"]
		},
		{
			"id": "1763250",
			"title": "Senior GoHighLevel (GHL) Systems & Funnel Architect — US Solar & Roofing ($10/hr + Uncapped $50/Sale Bonus | Part-Time A",
			"url": "https://www.onlinejobs.ph/jobseekers/job/senior-gohighlevel-ghl-systems-funnel-architect-us-solar-roofing-10-hr-uncapped-50-sale-bonus-part-time-a-1763250",
			"pay": "$10hr",
			"type": "Part Time",
			"posted": "2026-11-09 05:51:20",
			"snippet": "================================================== ROLE OVERVIEW & COMPENSATION ================================================== • Company: Smart Roofs Solar / Solar Homes 360/ Smart Homes Roofing(US-Based) • Schedule: Part-Time — 10 to 15 Hours/Week (Async execution + 2 brief EST overlap check-ins per week for strategy & reporting)… See More",
			"lanes": ["ghl"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1763212",
			"title": "HighLevel (GHL) Certified Specialist — Funnels, Automations & CRM for a Climate Tech Consultancy",
			"url": "https://www.onlinejobs.ph/jobseekers/job/highlevel-ghl-certified-specialist-funnels-automations-crm-for-a-climate-tech-consultancy-1763212",
			"pay": "$15/hour",
			"type": "Part Time",
			"posted": "2026-11-09 02:26:55",
			"snippet": "About Emotiva Emotiva is a US consultancy that helps climate tech and cleantech founders turn early traction into repeatable sales. We run our marketing, lead capture, and client pipeline in HighLevel. We're looking for a long-term partner who wants to… See More",
			"lanes": ["ghl"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1763197",
			"title": "AI Trading Automation Developer (Claude Code + Alpaca) – Part-Time, Ongoing",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ai-trading-automation-developer-claude-code-alpaca-part-time-ongoing-1763197",
			"pay": "",
			"type": "Part Time",
			"posted": "2026-11-09 01:13:01",
			"snippet": "ABOUT THE PROJECT My son and I are building an AI-assisted stock trading system that monitors the market around the clock, sends us alerts, and runs rule-based strategies. We set the strategy and make the decisions. You build, maintain, and… See More",
			"lanes": ["ai"],
			"stacks": ["Claude"]
		},
		{
			"id": "1762889",
			"title": "GoHighLevel Setup & Account Manager for US Contractor Clients (Long-Term)",
			"url": "https://www.onlinejobs.ph/jobseekers/job/gohighlevel-setup-account-manager-for-us-contractor-clients-long-term-1762889",
			"pay": "$5- $10 per hour",
			"type": "Part Time",
			"posted": "2026-11-07 18:43:04",
			"snippet": "ABOUT US Hard Hat Office is a small, growing US agency that runs the online side of contractor and home service businesses (builders, remodelers, roofers, concrete, landscaping). We set up and manage their website, Google Business Profile, Facebook and Instagram,… See More",
			"lanes": ["ghl"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1762865",
			"title": "AI Automation Developer (GoHighLevel + AI Voice Agents) - Long-Term",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ai-automation-developer-gohighlevel-ai-voice-agents-long-term-1762865",
			"pay": "$6-$12/hr depending on experience",
			"type": "Full Time",
			"posted": "2026-11-07 14:47:54",
			"snippet": "We're a growing US company building AI front-desk and patient reactivation systems for dental practices. We're hiring a long-term AI Automation Developer to build and maintain our client systems. WHAT YOU'LL DO - Build GoHighLevel workflows, calendars, pipelines and snapshots… See More",
			"lanes": ["ghl", "ai"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1762809",
			"title": "GoHighLevel AI Bot Specialist (Snapshot + Conversation AI + Client Support)",
			"url": "https://www.onlinejobs.ph/jobseekers/job/gohighlevel-ai-bot-specialist-snapshot-conversation-ai-client-support-1762809",
			"pay": "$1,000 - $1,400/month",
			"type": "Full Time",
			"posted": "2026-11-07 10:53:01",
			"snippet": "GOHIGHLEVEL AI BOT SPECIALIST - Snapshot + Conversation AI Owner (Full-Time, Remote, Long-Term) READ FIRST: I only consider a FRESH Loom recorded for THIS job. No old or reused videos. Start the video by saying SHIP, answer the questions below… See More",
			"lanes": ["ghl", "ai"],
			"stacks": ["GoHighLevel", "Voice AI"]
		},
		{
			"id": "1760297",
			"title": "GoHighLevel AI Automation & Meta Ads Expert",
			"url": "https://www.onlinejobs.ph/jobseekers/job/gohighlevel-ai-automation-meta-ads-expert-1760297",
			"pay": "Negotiable",
			"type": "Any",
			"posted": "2026-11-07 10:00:03",
			"snippet": "GoHighLevel AI Automation & Meta Ads Expert Location: Remote — Philippines Employment Type: Part-time initially, with the opportunity to transition to full-time very soon Compensation: Negotiable, based on experience and qualifications Start Date: Immediate About the Opportunity We're launching a… See More",
			"lanes": ["ghl", "ai"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1762583",
			"title": "Go High Level Automation & Marketing Specialist",
			"url": "https://www.onlinejobs.ph/jobseekers/job/go-high-level-automation-marketing-specialist-1762583",
			"pay": "$5.00/hour equivalent or agreed project-",
			"type": "Gig",
			"posted": "2026-11-07 01:20:55",
			"snippet": "Job Title: Go High Level Automation & Marketing Specialist Location: Remote, Philippines Engagement Type: Task-Based | Gig Work | Project-Based Starting Rate: $5.00/hour equivalent or agreed project-based rate Overview We are seeking a technically skilled, resourceful, and detail-oriented GoHighLevel Automation… See More",
			"lanes": ["ghl"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1762540",
			"title": "HighLevel Technical Builder — Part-Time, Remote",
			"url": "https://www.onlinejobs.ph/jobseekers/job/highlevel-technical-builder-part-time-remote-1762540",
			"pay": "$7 USD/hour",
			"type": "Part Time",
			"posted": "2026-11-07 00:21:58",
			"snippet": "About Taft Systems Taft Systems is a US-based HighLevel white-label fulfillment company. We build and support HighLevel accounts for marketing agencies across the country. Our team is fully remote, and we hold our builds to a high standard. We're hiring… See More",
			"lanes": ["ghl"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1762503",
			"title": "Senior GoHighLevel + Make.com Builder | WordPress, SEO & Claude Code | $2,000–$2,600/mo | US Medical Ed",
			"url": "https://www.onlinejobs.ph/jobseekers/job/senior-gohighlevel-make-com-builder-wordpress-seo-claude-code-2-000-2-600-mo-us-medical-ed-1762503",
			"pay": "$2,000–$2,600/month",
			"type": "Full Time",
			"posted": "2026-11-06 23:10:05",
			"snippet": "If you're good at GoHighLevel and Make.com, you're probably used to rebuilding the same agency snapshot for client after client and never seeing what happens next. This is the other kind of job: one company, one system, and you own… See More",
			"lanes": ["ghl", "ai"],
			"stacks": [
				"GoHighLevel",
				"Make",
				"Claude"
			]
		},
		{
			"id": "1762495",
			"title": "$1,000 - $1,400 for High-End GoHighLevel (GHL) Specialist - Website Template, Automation's & Snapshot Developer",
			"url": "https://www.onlinejobs.ph/jobseekers/job/1-000-1-400-for-high-end-gohighlevel-ghl-specialist-website-template-automation-s-snapshot-developer-1762495",
			"pay": "$1000 - $1400",
			"type": "Any",
			"posted": "2026-11-06 22:52:05",
			"snippet": "Project-Based / Part-Time (With potential to scale to Full-Time as we onboard clients) About the Role: I am an agency owner launching a high-end web design and SaaS fulfilment service for local tradesmen in the UK (plumbers, electricians, landscapers, etc.).… See More",
			"lanes": ["ghl"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1762432",
			"title": "GoHighLevel SaaS Developer & Automation Specialist – Homecare OS",
			"url": "https://www.onlinejobs.ph/jobseekers/job/gohighlevel-saas-developer-automation-specialist-homecare-os-1762432",
			"pay": "$800-$1000/mo",
			"type": "Any",
			"posted": "2026-11-06 20:14:51",
			"snippet": "We are looking for an experienced GoHighLevel (GHL) SaaS Developer to complete and launch our existing Homecare OS platform, a subscription-based CRM and automation system designed for homecare agencies in the United States. Important: Our GHL snapshot already exists. We… See More",
			"lanes": ["ghl"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1762401",
			"title": "AI Automation & Systems Specialist",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ai-automation-systems-specialist-1762401",
			"pay": "TBD",
			"type": "Any",
			"posted": "2026-11-06 18:08:54",
			"snippet": "JOB OVERVIEW We are a growing VA operations and project management agency supporting entrepreneurs, founders, coaches, and online businesses in the United States. We help clients streamline operations, build scalable systems, manage projects, and improve business processes so they can… See More",
			"lanes": ["ai"],
			"stacks": []
		},
		{
			"id": "1762311",
			"title": "AI Automation & Systems Specialist",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ai-automation-systems-specialist-1762311",
			"pay": "$7-$10/hour",
			"type": "Any",
			"posted": "2026-11-06 12:40:17",
			"snippet": "We are a growing VA operations and project management agency supporting entrepreneurs, founders, coaches, and online businesses in the United States. Our team helps clients streamline operations, build scalable systems, manage projects, hire top talent, and improve business processes so… See More",
			"lanes": ["ai"],
			"stacks": []
		},
		{
			"id": "1762263",
			"title": "GoHighLevel AI Automation & Implementation Expert",
			"url": "https://www.onlinejobs.ph/jobseekers/job/gohighlevel-ai-automation-implementation-expert-1762263",
			"pay": "Negotiable",
			"type": "Any",
			"posted": "2026-11-06 10:46:50",
			"snippet": "GoHighLevel AI Automation & Implementation Expert Location: Remote – Philippines Job Type: Part-Time Initially, With Opportunity to Grow Into Full-Time very soon. Compensation: Negotiable Based on Experience Start Date: Immediate About the Opportunity We are launching a U.S.-based marketing and… See More",
			"lanes": ["ghl", "ai"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1417684",
			"title": "GHL Automation Specialist",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ghl-automation-specialist-1417684",
			"pay": "N/A",
			"type": "Part Time",
			"posted": "2026-11-06 05:46:43",
			"snippet": "Summary Position: Part-Time Go HighLevel (GHL) Automation Specialist | Funnel & CRM Optimization We are looking for a highly skilled and experienced Go HighLevel (GHL) Automation Specialist to support our team in optimizing marketing funnels and automating CRM workflows. This… See More",
			"lanes": ["ghl"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1761765",
			"title": "Part-Time Web Developer (GoHighLevel)",
			"url": "https://www.onlinejobs.ph/jobseekers/job/part-time-web-developer-gohighlevel-1761765",
			"pay": "$10/hour",
			"type": "Part Time",
			"posted": "2026-11-05 17:58:47",
			"snippet": "We're a US-based boutique marketing consultancy, hiring a part-time web developer to build and maintain websites and landing pages in GoHighLevel for our firm and our clients. This is an ongoing role, not a one-off project. You should think like… See More",
			"lanes": ["ghl"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1761478",
			"title": "Automation Specialist WANTED– GoHighLevel, Zapier, AI (Assistable.ai)",
			"url": "https://www.onlinejobs.ph/jobseekers/job/automation-specialist-wanted-gohighlevel-zapier-ai-assistable-ai-1761478",
			"pay": "55,000 php - 70,000 php/mo Starting",
			"type": "Full Time",
			"posted": "2026-11-05 05:30:12",
			"snippet": "If you’re passionate about automation, love solving problems with tech, and want to help small businesses grow, then this role might be a perfect fit. Please read this post carefully (applications that don’t follow the instructions won’t be considered). I’m… See More",
			"lanes": ["ghl", "ai"],
			"stacks": [
				"GoHighLevel",
				"Zapier",
				"AI chat"
			]
		},
		{
			"id": "1761425",
			"title": "CRM Administrator: ACT! & GoHighLevel (Workflows, Integrations, Email Domains)",
			"url": "https://www.onlinejobs.ph/jobseekers/job/crm-administrator-act-gohighlevel-workflows-integrations-email-domains-1761425",
			"pay": "Negotiable",
			"type": "Full Time",
			"posted": "2026-11-05 04:20:59",
			"snippet": "ABOUT LINEHAUL STATION LineHaul Station is building a new kind of truck terminal for over-the-road drivers, and it's nothing like a standard terminal or truck stop. We pair secure, gated OTR parking with real amenities: private showers, a members' grill,… See More",
			"lanes": ["ghl"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1761341",
			"title": "HighLevel (GoHighLevel) expert needed: agency CRM + 2 industry snapshots (UK, fixed price)",
			"url": "https://www.onlinejobs.ph/jobseekers/job/highlevel-gohighlevel-expert-needed-agency-crm-2-industry-snapshots-uk-fixed-price-1761341",
			"pay": "$1000+",
			"type": "Gig",
			"posted": "2026-11-05 02:03:31",
			"snippet": "We’re a UK marketing agency building a done-for-you lead-generation and sales system on HighLevel for two industries: home improvement/trades and independent car dealers. Detailed written specs are ready (pipelines, fields, calendars, forms, message copy, AI prompts, workflows and test checklists).… See More",
			"lanes": ["ghl"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1751686",
			"title": "Project Manager, build website, go high level crm",
			"url": "https://www.onlinejobs.ph/jobseekers/job/project-manager-build-website-go-high-level-crm-1751686",
			"pay": "$6 a hour",
			"type": "Part Time",
			"posted": "2026-11-05 00:54:17",
			"snippet": "# Hiring: Full-Service Digital Marketing & GoHighLevel Agency **U.S. Commercial Mortgage & Real Estate Businesses** We are seeking an experienced, highly skilled digital marketing and website development agency to build, launch, and manage a complete online marketing platform for our… See More",
			"lanes": ["ghl"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1761162",
			"title": "Digital Marketing, Web Dev, AI Automation Specialist (Junior)",
			"url": "https://www.onlinejobs.ph/jobseekers/job/digital-marketing-web-dev-ai-automation-specialist-junior-1761162",
			"pay": "₱35,000 – ₱50,000",
			"type": "Full Time",
			"posted": "2026-11-04 20:20:39",
			"snippet": "About us Leading Australian digital marketing agency (15 years established) operating at the cutting edge of AI execution, digital marketing, and modern web development. 💡 What You’ll Do AI & Workflow Automations: Build, test, and maintain custom client automations and… See More",
			"lanes": ["ai"],
			"stacks": []
		},
		{
			"id": "1761048",
			"title": "Senior Full-Stack AI Engineer: Finish and Launch Our AI Apps",
			"url": "https://www.onlinejobs.ph/jobseekers/job/senior-full-stack-ai-engineer-finish-and-launch-our-ai-apps-1761048",
			"pay": "2000",
			"type": "Full Time",
			"posted": "2026-11-04 15:39:17",
			"snippet": "Full-time, 40 hours/week, with at least 4 hours overlapping 9am–5pm US Central Time. Salary: $1,800–$3,000 USD/month, based on experience. We’re a US company with several AI apps that are mostly built but not finished. We don’t need more features. We… See More",
			"lanes": ["ai"],
			"stacks": []
		},
		{
			"id": "1760920",
			"title": "WE’RE HIRING: PART-TIME AI AUTOMATION SPECIALIST (INTERN ROLE)",
			"url": "https://www.onlinejobs.ph/jobseekers/job/we-re-hiring-part-time-ai-automation-specialist-intern-role-1760920",
			"pay": "",
			"type": "Part Time",
			"posted": "2026-11-04 09:20:20",
			"snippet": "We’re looking for a tech-savvy individual to join our team as a Part-Time AI Automation Specialist. This is a remote position. Responsibilities: Create and manage AI-powered automations. Automate repetitive business tasks and workflows. Improve business processes using AI tools. Assist… See More",
			"lanes": ["ai"],
			"stacks": []
		},
		{
			"id": "1760786",
			"title": "Senior Software and AI Automation Engineer",
			"url": "https://www.onlinejobs.ph/jobseekers/job/senior-software-and-ai-automation-engineer-1760786",
			"pay": "$1,500+",
			"type": "Full Time",
			"posted": "2026-11-04 04:57:57",
			"snippet": "GoHighLevel, LinkedIn Sales Navigator, Websites and Investor Portals Full-time remote | Flexible hours | Opportunity for leadership growth Starting compensation: US$1,500 per month during a 90-day paid trial. Victory Rock Capital is seeking a seasoned software engineer who can build… See More",
			"lanes": ["ghl", "ai"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1631453",
			"title": "Website and Funnel Developer (Go High Level)",
			"url": "https://www.onlinejobs.ph/jobseekers/job/website-and-funnel-developer-go-high-level-1631453",
			"pay": "4",
			"type": "Part Time",
			"posted": "2026-11-04 04:23:58",
			"snippet": "I am looking for someone to completely revamp my existing funnel, build automations, embed google maps on site, create payment processors for website, manage email flows, as well as work on projects continuously to keep the different brands fresh. I… See More",
			"lanes": ["ghl"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1760418",
			"title": "AI Automation Implementation & Operations Specialist",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ai-automation-implementation-operations-specialist-1760418",
			"pay": "$900-1500 USD/month",
			"type": "Full Time",
			"posted": "2026-11-03 15:42:23",
			"snippet": "Do you get frustrated with repetitive manual processes (+ HATE disorganised systems) and instinctively think of ways to automate processes to make your life easier? You will be the integrator between teachers, students and parents, taking ownership of all processes… See More",
			"lanes": ["ai"],
			"stacks": []
		},
		{
			"id": "1760333",
			"title": "AI Business Systems & Workflow Automation Specialist",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ai-business-systems-workflow-automation-specialist-1760333",
			"pay": "₱855",
			"type": "Part Time",
			"posted": "2026-11-03 10:42:46",
			"snippet": "About the Position Chestnut Brook Consulting is seeking an exceptionally capable, independent, and technically resourceful professional to help design and build business management systems, AI-assisted workflows, dashboards, and operational automation solutions. We are looking for a builder, a problem solver,… See More",
			"lanes": ["ai"],
			"stacks": []
		},
		{
			"id": "1514358",
			"title": "AI CEO Builder / Senior Automation Engineer (GoHighLevel + Multi-Agent AI + Google Workspace Automations)",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ai-ceo-builder-senior-automation-engineer-gohighlevel-multi-agent-ai-google-workspace-automations-1514358",
			"pay": "$730.00 - $895.00 per month (?41,700.00 - ?50,900.00 per month)",
			"type": "Any",
			"posted": "2026-11-03 01:27:10",
			"snippet": "We are hiring a senior-level AI automation architect who can build a complete AI CEO System that runs business operations across multiple companies. This role requires zero training, zero hand-holding, and real experience building advanced automation systems. If you are… See More",
			"lanes": ["ghl", "ai"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1759857",
			"title": "AI Automation Engineer – Claude API, Shopify & Facebook/TikTok Ads",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ai-automation-engineer-claude-api-shopify-facebook-tiktok-ads-1759857",
			"pay": "$2,000 – $2,500/month",
			"type": "Full Time",
			"posted": "2026-11-02 22:00:11",
			"snippet": "We're a fast-growing e-commerce company building AI-powered systems to launch products and ad campaigns at scale. We're looking for a technical builder who can design and run end-to-end automations, not just use tools, but connect them. You'll work directly with… See More",
			"lanes": ["ai"],
			"stacks": ["Claude", "API"]
		},
		{
			"id": "1759832",
			"title": "High-Paying AI/Automation Specialist",
			"url": "https://www.onlinejobs.ph/jobseekers/job/high-paying-ai-automation-specialist-1759832",
			"pay": "49,000 per Month",
			"type": "Full Time",
			"posted": "2026-11-02 21:00:25",
			"snippet": "To apply please click the link: https://simple-recruitment.vercel.app/careers/58d8bd37-11bc-49eb-9a7e-6a6ff116668d?src=onlinejobs JOB OVERVIEW Are you a developer or programmer looking to develop your AI and Automation skills while working with a US tech company? We are a US-based web development company with 5000+ customers.… See More",
			"lanes": ["ai"],
			"stacks": []
		},
		{
			"id": "1759781",
			"title": "GoHighLevel Expert – Websites from Snapshots, Sub-Accounts",
			"url": "https://www.onlinejobs.ph/jobseekers/job/gohighlevel-expert-websites-from-snapshots-sub-accounts-1759781",
			"pay": "5$/hour",
			"type": "Any",
			"posted": "2026-11-02 18:37:02",
			"snippet": "We help businesses that don’t have a website get online fast. We use GoHighLevel snapshots to launch simple, professional websites and basic automations for each new client. We need a GoHighLevel expert who can take a new client from sign-up… See More",
			"lanes": ["ghl"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1759738",
			"title": "AI Automation Developer (Claude): build the AI back office for a Swiss experience business",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ai-automation-developer-claude-build-the-ai-back-office-for-a-swiss-experience-business-1759738",
			"pay": "",
			"type": "Any",
			"posted": "2026-11-02 16:57:36",
			"snippet": "**AI Automation Developer (Claude): build the AI back office for a Swiss experience business** **Read this first. If your application doesn't start with a video link, I won't open it.** A CV is welcome, but it goes below the video.… See More",
			"lanes": ["ai"],
			"stacks": ["Claude"]
		},
		{
			"id": "1593846",
			"title": "GoHighLevel & Airtable Implementation Specialist",
			"url": "https://www.onlinejobs.ph/jobseekers/job/gohighlevel-airtable-implementation-specialist-1593846",
			"pay": "$5.97/hour",
			"type": "Any",
			"posted": "2026-11-02 06:43:46",
			"snippet": "Type: Full-Time Contract / Project-Based Industry: Home Care / Healthcare Recruitment Start Date: Immediate About the Project We need an experienced GoHighLevel (GHL) and Airtable specialist to implement a complete Applicant Tracking System (ATS) for home care agencies. The system… See More",
			"lanes": ["ghl"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1759424",
			"title": "GoHighLevel Automation, Apify & CRM Integration Specialist",
			"url": "https://www.onlinejobs.ph/jobseekers/job/gohighlevel-automation-apify-crm-integration-specialist-1759424",
			"pay": "$400",
			"type": "Gig",
			"posted": "2026-11-01 20:33:09",
			"snippet": "Job Type: Project-Based with Long-Term Opportunities Start Date: Immediately Initial Project Deadline: Within 5 days Grit Systems is a growing US-focused digital services company helping contractors, including plumbers, roofers, HVAC companies, electricians and other home service businesses, grow through professional… See More",
			"lanes": ["ghl"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1759332",
			"title": "Claude AI Automation & Prompt Engineering Specialist",
			"url": "https://www.onlinejobs.ph/jobseekers/job/claude-ai-automation-prompt-engineering-specialist-1759332",
			"pay": "$3/hr",
			"type": "Part Time",
			"posted": "2026-11-01 10:02:02",
			"snippet": "We are looking for a smart, resourceful, hands-on AI Automation Specialist who can use Claude AI, Claude Code, and terminal-based tools to build, execute, and manage repeatable business tasks. This is an execution-focused role, not just prompt writing. We need… See More",
			"lanes": ["ai"],
			"stacks": ["Claude"]
		},
		{
			"id": "1759183",
			"title": "GoHighLevel Automation & Systems Lead — Full-Time, Long-Term",
			"url": "https://www.onlinejobs.ph/jobseekers/job/gohighlevel-automation-systems-lead-full-time-long-term-1759183",
			"pay": "",
			"type": "Full Time",
			"posted": "2026-10-31 19:25:56",
			"snippet": "Blue Carrot Solutions is an established US-based company expanding into GoHighLevel automation services for local businesses. We currently have two wonderful team members in the Philippines, Anna and Maiden. We're looking for a third person who brings strong technical GHL… See More",
			"lanes": ["ghl"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1758708",
			"title": "AI Automation Developers",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ai-automation-developers-1758708",
			"pay": "negotiable",
			"type": "Full Time",
			"posted": "2026-10-30 14:11:07",
			"snippet": "We’re looking for an analytical, curious AI Automation Developers to help us improve business processes using Claude and practical automation. We value clear thinking, great communication and the ability to understand a problem, test ideas and build a reliable solution.… See More",
			"lanes": ["ai"],
			"stacks": ["Claude"]
		},
		{
			"id": "1758425",
			"title": "AI Automation & Agent Development Specialist",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ai-automation-agent-development-specialist-1758425",
			"pay": "",
			"type": "Any",
			"posted": "2026-10-30 01:48:55",
			"snippet": "Job Title: AI Automation & Agent Development Specialist Company: Spectrum Florida Inc. — Umbrella of Companies Department: Technology, Systems & Business Operations Employment Type: Full-Time or Contract (Based on Experience) Location: To Be Determined Position Overview Spectrum Florida Inc. is… See More",
			"lanes": ["ai"],
			"stacks": []
		},
		{
			"id": "1758380",
			"title": "GHL specialist to build funnel",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ghl-specialist-to-build-funnel-1758380",
			"pay": "tpd",
			"type": "Gig",
			"posted": "2026-10-30 00:47:28",
			"snippet": "build funnels, pipelines, and automation systems. We provide workflow blueprints; you handle implementation, testing, and troubleshooting. REQUIRED EXPERIENCE • 3+ years of hands-on GoHighLevel experience. • Built systems for credit repair, MCA/business funding, personal funding, mortgage lending, or equipment financing.… See More",
			"lanes": ["ghl"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1758355",
			"title": "AI Automation Developer (Full Time, UK Hours)",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ai-automation-developer-full-time-uk-hours-1758355",
			"pay": "$800-1500/month",
			"type": "Full Time",
			"posted": "2026-10-30 00:22:54",
			"snippet": "WHO WE ARE Your Social Currency is a London content agency. We make content for big creators, some with over a million followers. We are growing fast, and we need one developer who owns all the small tools that make… See More",
			"lanes": ["ai"],
			"stacks": []
		},
		{
			"id": "1720036",
			"title": "Backend AI Automation Engineer (Python, PostgreSQL)",
			"url": "https://www.onlinejobs.ph/jobseekers/job/backend-ai-automation-engineer-python-postgresql-1720036",
			"pay": "$600/month starting",
			"type": "Full Time",
			"posted": "2026-10-30 00:18:50",
			"snippet": "Looking for a killer backend engineer to join my agency. Responsibilities include building databases, SQL, automations, AI agents and HTTP calls, and making amendments & sporadic changes to code where needed. Must-haves: - Experience with Make.com , HTTP, FastAPI, etc.)… See More",
			"lanes": ["ai"],
			"stacks": ["Make", "Python"]
		},
		{
			"id": "1758171",
			"title": "Freelance AI Automation Developer (OpenClaw)",
			"url": "https://www.onlinejobs.ph/jobseekers/job/freelance-ai-automation-developer-openclaw-1758171",
			"pay": "800",
			"type": "Part Time",
			"posted": "2026-10-29 16:20:55",
			"snippet": "Immediate start | Remote | Part-time | 20 hours/week | AUD $9–$10/hour We’re looking for a resourceful, AI Automation Developer to support an Australian business with an existing OpenClaw setup and approximately 20 automations already in place. Responsibilities: - Maintain,… See More",
			"lanes": ["ai"],
			"stacks": []
		},
		{
			"id": "1757511",
			"title": "AI Automation Engineer",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ai-automation-engineer-1757511",
			"pay": "$1,200-2,000/month",
			"type": "Full Time",
			"posted": "2026-10-28 17:09:52",
			"snippet": "AI Automation Engineer: builds the automations and AI tools that keep SoFyre's ecommerce operations running with less manual work. Full-time, remote, work from home. Reports to the COO. PURPOSE Your job is to find the manual, repeated work in our… See More",
			"lanes": ["ai"],
			"stacks": []
		},
		{
			"id": "1757255",
			"title": "AI Operations and Email Automation Specialist",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ai-operations-and-email-automation-specialist-1757255",
			"pay": "Based on experience",
			"type": "Any",
			"posted": "2026-10-28 06:44:51",
			"snippet": "We're looking for a hands-on operator who can build better systems and manage client email automation. You should be comfortable turning a recurring task into a clear, tested process, using AI to reduce manual work, and checking that the finished… See More",
			"lanes": ["ai"],
			"stacks": []
		},
		{
			"id": "1757244",
			"title": "GoHighLevel Funnel & Automation Specialist — Financial services ,Credit Repair & Business Funding",
			"url": "https://www.onlinejobs.ph/jobseekers/job/gohighlevel-funnel-automation-specialist-financial-services-credit-repair-business-funding-1757244",
			"pay": "with potential hourly after job",
			"type": "Gig",
			"posted": "2026-10-28 06:17:33",
			"snippet": "Golden Credit and Golden Funding Capital are hiring an experienced GHL specialist to build funnels, pipelines, and automation systems. We provide workflow blueprints; you handle implementation, testing, and troubleshooting. REQUIRED EXPERIENCE • 3+ years of hands-on GoHighLevel experience. • Built… See More",
			"lanes": ["ghl"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1441517",
			"title": "Senior Full-Stack AI Developer - Whitelabel SaaS Platform",
			"url": "https://www.onlinejobs.ph/jobseekers/job/senior-full-stack-ai-developer-whitelabel-saas-platform-1441517",
			"pay": "negotiable",
			"type": "Full Time",
			"posted": "2026-10-28 04:18:37",
			"snippet": "Location: Remote Employment Type: Full-time Contract/Employee Salary Range: Negotiable Experience Level: Senior (8-12+ years) About This Opportunity - before I start, we're building MANY applications, tools and automations, we have over 200,000 business owners who've come to us to scale… See More",
			"lanes": ["ai"],
			"stacks": []
		},
		{
			"id": "1485443",
			"title": "We’re Hiring: GHL + CloseBot Automation Expert (Full-Time / Contract)",
			"url": "https://www.onlinejobs.ph/jobseekers/job/we-re-hiring-ghl-closebot-automation-expert-full-time-contract-1485443",
			"pay": "$600 - $1500",
			"type": "Full Time",
			"posted": "2026-10-28 04:18:37",
			"snippet": "We’re looking for a marketing automation builder who can bring chatbots to life — someone fluent in GoHighLevel (GHL), CloseBot-style AI chatbot flows, and obsessed with optimizing funnels, follow-ups, and conversions. If you live for workflows, love connecting APIs, and… See More",
			"lanes": ["ghl", "ai"],
			"stacks": [
				"GoHighLevel",
				"AI chat",
				"API"
			]
		},
		{
			"id": "1756059",
			"title": "Senior GoHighLevel Systems & AI Automation Specialist | Funnels, CRM & Business Operations",
			"url": "https://www.onlinejobs.ph/jobseekers/job/senior-gohighlevel-systems-ai-automation-specialist-funnels-crm-business-operations-1756059",
			"pay": "negotiable",
			"type": "Part Time",
			"posted": "2026-10-26 11:40:08",
			"snippet": "# Senior GoHighLevel Systems & AI Automation Specialist | Funnels, CRM & Business Operations **Job Type:** Part-Time to Start (20–25 hours/week), with opportunity to grow into full-time **Location:** Remote – Philippines **Compensation:** Competitive, based on proven skills and experience **Schedule:**… See More",
			"lanes": ["ghl", "ai"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1755845",
			"title": "Voice AI & Automation Specialist",
			"url": "https://www.onlinejobs.ph/jobseekers/job/voice-ai-automation-specialist-1755845",
			"pay": "$6-10 /hr (priced per project)",
			"type": "Gig",
			"posted": "2026-10-25 23:46:37",
			"snippet": "Be Part of the AI Wave Are you passionate about building AI agents and automations that solve real-world problems? 𝗔𝗯𝗼𝘂𝘁 𝗨𝘀: Hi, I'm Harry, founder of AddSomeAI, a UK-based AI and automation development firm. We work directly with business owners… See More",
			"lanes": ["ai"],
			"stacks": ["Voice AI"]
		},
		{
			"id": "1746169",
			"title": "GoHighLevel Strategist / Automation Specialist (Part-Time, Growth to Full-Time)",
			"url": "https://www.onlinejobs.ph/jobseekers/job/gohighlevel-strategist-automation-specialist-part-time-growth-to-full-time-1746169",
			"pay": "Up to $10 per hour",
			"type": "Part Time",
			"posted": "2026-10-25 20:32:11",
			"snippet": "Here's a paste-ready version: **GoHighLevel Strategist / Automation Specialist (Part-Time, Growth to Full-Time)** **ABOUT US** Find My Limo is a luxury transportation company in Metro Detroit, Michigan. We run 41 managed vehicles plus a 100+ vehicle affiliate network, including Rolls-Royce,… See More",
			"lanes": ["ghl"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1733794",
			"title": "Full-Time AI Automation Developer | n8n, AI Agents, Python/JavaScript, GitHub",
			"url": "https://www.onlinejobs.ph/jobseekers/job/full-time-ai-automation-developer-n8n-ai-agents-python-javascript-github-1733794",
			"pay": "2500-4000",
			"type": "Full Time",
			"posted": "2026-10-24 18:47:23",
			"snippet": "FULL-TIME AI AUTOMATION & FULL-STACK DEVELOPER n8n | AI Agents | OpenClaw | Hermes | Claude Code | Codex | Grok | GitHub We are hiring a dedicated developer to work directly with the founder and build, deploy, maintain, and… See More",
			"lanes": ["ai"],
			"stacks": [
				"n8n",
				"Claude",
				"Python"
			]
		},
		{
			"id": "1755291",
			"title": "GoHighLevel Specialist — AI Agents, Automations & Client Fulfillment",
			"url": "https://www.onlinejobs.ph/jobseekers/job/gohighlevel-specialist-ai-agents-automations-client-fulfillment-1755291",
			"pay": "",
			"type": "Part Time",
			"posted": "2026-10-24 03:39:43",
			"snippet": "We’re hiring an experienced GoHighLevel specialist to help us launch and manage AI receptionist and automation systems for service businesses. This position starts part-time at approximately 20 hours per week. Our intention is to grow it into a full-time role… See More",
			"lanes": ["ghl"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1755223",
			"title": "AI Automation Developer (Claude Code)",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ai-automation-developer-claude-code-1755223",
			"pay": "1000-2000",
			"type": "Full Time",
			"posted": "2026-10-24 01:18:06",
			"snippet": "We're looking for an experienced AI Automation Developer who builds real software with Claude Code, to help us build and run the AI infrastructure behind our performance marketing agency. We already run a team of AI agents in Slack, our… See More",
			"lanes": ["ai"],
			"stacks": ["Claude"]
		},
		{
			"id": "1754855",
			"title": "N8N Systems & Automation Operator",
			"url": "https://www.onlinejobs.ph/jobseekers/job/n8n-systems-automation-operator-1754855",
			"pay": "Negotiable",
			"type": "Gig",
			"posted": "2026-10-23 10:24:42",
			"snippet": "We are seeking an experienced n8n Systems & Automation Operator to support our self-hosted infrastructure, server management, and automation projects. Candidates should have practical experience deploying and maintaining applications on VPS/VM servers, developing browser automations, and using AI tools for… See More",
			"lanes": ["ai"],
			"stacks": ["n8n"]
		},
		{
			"id": "1754853",
			"title": "Self-Hosted n8n & Automation Technician",
			"url": "https://www.onlinejobs.ph/jobseekers/job/self-hosted-n8n-automation-technician-1754853",
			"pay": "Negotiable",
			"type": "Gig",
			"posted": "2026-10-23 10:21:14",
			"snippet": "We are looking for an experienced technician to manage our self-hosted n8n environments, VPS/VM infrastructure, and automation workflows. This role requires hands-on experience with server administration, Playwright/Puppeteer, AI-assisted development, and troubleshooting technical systems. This is an ongoing, as-needed position with… See More",
			"lanes": ["ai"],
			"stacks": ["n8n"]
		},
		{
			"id": "1754684",
			"title": "GoHighLevel Specialist – Websites, Workflows & Automations (Part-Time)",
			"url": "https://www.onlinejobs.ph/jobseekers/job/gohighlevel-specialist-websites-workflows-automations-part-time-1754684",
			"pay": "",
			"type": "Part Time",
			"posted": "2026-10-23 04:16:26",
			"snippet": "I'm looking for an experienced, highly reliable GoHighLevel Specialist to help build, customize, deploy, and maintain websites, landing pages, snapshots, workflows, and automation systems for our digital marketing agency. This is a part-time, flexible, as-needed position working directly with me,… See More",
			"lanes": ["ghl"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1754639",
			"title": "E-Commerce, AI & Systems Automation Specialist",
			"url": "https://www.onlinejobs.ph/jobseekers/job/e-commerce-ai-systems-automation-specialist-1754639",
			"pay": "Negotiable",
			"type": "Full Time",
			"posted": "2026-10-23 02:51:08",
			"snippet": "Location: General Santos City, Philippines Work Setup: On-site / Office-based About the Role We’re looking for a tech-savvy and solutions-oriented E-Commerce, AI & Systems Automation Specialist to optimize our Shopify store, integrate business systems, and automate workflows. This role is… See More",
			"lanes": ["ai"],
			"stacks": []
		},
		{
			"id": "1726375",
			"title": "Hiring: Senior Voice and Chat AI Engineer",
			"url": "https://www.onlinejobs.ph/jobseekers/job/hiring-senior-voice-and-chat-ai-engineer-1726375",
			"pay": "TBD",
			"type": "Full Time",
			"posted": "2026-10-22 23:50:46",
			"snippet": "Important Notice to Applicants: Please note that we are only contacting and communicating with candidates through OnlineJobsPH. Any applications or direct contact made outside of these channels, including emails, social media messages, direct messages to our CEO, or messages sent… See More",
			"lanes": ["ai"],
			"stacks": []
		},
		{
			"id": "1754486",
			"title": "AI Automation & Software Developer | Python, n8n, AI & APIs",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ai-automation-software-developer-python-n8n-ai-apis-1754486",
			"pay": "800 a month",
			"type": "Full Time",
			"posted": "2026-10-22 22:36:56",
			"snippet": "Employment: Paid project-based initially, with potential for a long-term position Ongoing budget: £800–£1,000 per month, depending on agreed hours and responsibilities We are a UK-based group operating supermarkets, restaurants, cafés and wholesale businesses. We are seeking an experienced AI Automation… See More",
			"lanes": ["ai"],
			"stacks": [
				"n8n",
				"Python",
				"API"
			]
		},
		{
			"id": "1623550",
			"title": "Assistant Automation Specialist (Go High Level)",
			"url": "https://www.onlinejobs.ph/jobseekers/job/assistant-automation-specialist-go-high-level-1623550",
			"pay": "TBD",
			"type": "Any",
			"posted": "2026-10-22 15:11:38",
			"snippet": "We're Hiring: Assistant Automation Specialist (GoHighLevel / GHL) Company: Clix Dental Work Setup: Remote | Full-Time Opportunity Love Building Automations That Actually Work? Let's Talk! Clix Dental is looking for a detail-oriented, proactive, and technically skilled Assistant Automation Specialist to… See More",
			"lanes": ["ghl"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1753880",
			"title": "AI Automation Engineer (N8n, Zapier, APIs)",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ai-automation-engineer-n8n-zapier-apis-1753880",
			"pay": "1,200",
			"type": "Full Time",
			"posted": "2026-10-22 00:00:19",
			"snippet": "Please apply only if you’re willing to complete a short trial task as part of the selection process. This will help us assess your problem-solving skills, technical ability, and how you approach building automation systems in practice. We’re looking for… See More",
			"lanes": ["ai"],
			"stacks": [
				"n8n",
				"Zapier",
				"API"
			]
		},
		{
			"id": "1739429",
			"title": "Job title: Senior AI Automation Engineer (n8n, APIs, Claude/GPT, Shopify, Odoo) (Full-time)",
			"url": "https://www.onlinejobs.ph/jobseekers/job/job-title-senior-ai-automation-engineer-n8n-apis-claude-gpt-shopify-odoo-full-time-1739429",
			"pay": "2000",
			"type": "Full Time",
			"posted": "2026-10-21 16:18:32",
			"snippet": "Type of work: Full-time, remote, long-term (occasional in-person work sprints) Salary: USD 2,000–3,500 / month, depending on experience (+ performance bonus) Hours: Flexible, with daily overlap with Manila time (UTC+8) About us We are an international group running e-commerce brands… See More",
			"lanes": ["ai"],
			"stacks": [
				"n8n",
				"Claude",
				"API"
			]
		},
		{
			"id": "1753179",
			"title": "HIRING: AI AUTOMATION & SYSTEMS MANAGER",
			"url": "https://www.onlinejobs.ph/jobseekers/job/hiring-ai-automation-systems-manager-1753179",
			"pay": "$600 - $2,200+/ Month",
			"type": "Full Time",
			"posted": "2026-10-20 23:10:35",
			"snippet": "# HIRING: AI AUTOMATION & SYSTEMS MANAGER **Full-Time | Remote | Long-Term Opportunity** **Compensation: $600–$2,200/month USD, depending on experience and demonstrated ability.** Retiredin365 is seeking an exceptional **AI automation specialist, GoHighLevel expert, and funnel builder** to take ownership of our… See More",
			"lanes": ["ghl", "ai"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1752838",
			"title": "AI Automation & Process Manager",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ai-automation-process-manager-1752838",
			"pay": "350",
			"type": "Part Time",
			"posted": "2026-10-20 10:07:14",
			"snippet": "We're looking for an experienced AI Automation & Process Manager who can organize, optimize, and automate our daily business operations using AI tools. Our business operates multiple e-commerce stores, and we want to reduce manual work, improve team efficiency, and… See More",
			"lanes": ["ai"],
			"stacks": []
		},
		{
			"id": "1752277",
			"title": "Closara: Technical Operator — GoHighLevel Weapon",
			"url": "https://www.onlinejobs.ph/jobseekers/job/closara-technical-operator-gohighlevel-weapon-1752277",
			"pay": "1000 USD Per Month",
			"type": "Full Time",
			"posted": "2026-10-19 17:42:54",
			"snippet": "The Conversion OS · Complex Workflows · Voice AI · Lead Distribution · Snapshots at Scale You don’t just use GoHighLevel. You bend it to your will. Here, that IS the job. Remote · Full-time · AEST hours (10am–7pm Melbourne,… See More",
			"lanes": ["ghl", "ai"],
			"stacks": ["GoHighLevel", "Voice AI"]
		},
		{
			"id": "1751466",
			"title": "Automation Engineer (Python and AI workflows)",
			"url": "https://www.onlinejobs.ph/jobseekers/job/automation-engineer-python-and-ai-workflows-1751466",
			"pay": "",
			"type": "Part Time",
			"posted": "2026-10-17 15:18:26",
			"snippet": "We’re a small, growing company that builds business automations for small and mid-sized companies. We build each solution once and roll it out to many clients. Small team, direct contact with the founders, and everything we build must be easy… See More",
			"lanes": ["ai"],
			"stacks": ["Python"]
		},
		{
			"id": "1751166",
			"title": "n8n + Google Sheets Automation Expert: Shopify Order Tracking Dashboard",
			"url": "https://www.onlinejobs.ph/jobseekers/job/n8n-google-sheets-automation-expert-shopify-order-tracking-dashboard-1751166",
			"pay": "$500 to $1000 USD Monthly",
			"type": "Any",
			"posted": "2026-10-17 01:10:48",
			"snippet": "We run two Shopify brands and want one Google Sheet that automatically tracks every order from purchase to delivery, including costs and profit. What you’ll build An n8n workflow that pulls orders from Shopify and/or TrueProfit and our tracking app,… See More",
			"lanes": ["ai"],
			"stacks": ["n8n"]
		},
		{
			"id": "1730634",
			"title": "AI AUTOMATION & AI CLONE ENGINEER SSS and Retirement",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ai-automation-ai-clone-engineer-sss-and-retirement-1730634",
			"pay": "1250 to 2000 USD per month",
			"type": "Full Time",
			"posted": "2026-10-16 18:29:50",
			"snippet": "AI AUTOMATION & AI CLONE ENGINEER Full-Time Remote — Philippines $1,250–$2,000 USD/Month + Bonuses + Benefits + Technology Allowance We are looking for **one exceptional AI builder** to join our team full-time and, ideally, stay with us for years. **This… See More",
			"lanes": ["ai"],
			"stacks": []
		},
		{
			"id": "1750303",
			"title": "AI Automation Specialist / AI Operations Architect",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ai-automation-specialist-ai-operations-architect-1750303",
			"pay": "approximately $1,330.00 - $1,625.00 per",
			"type": "Gig",
			"posted": "2026-10-15 17:30:48",
			"snippet": "Hiring: AI Automation Specialist / AI Operations Architect I’m building an AI-powered operating system to help manage multiple businesses across luxury hospitality, events, music, wine and consulting. I’m looking for an experienced specialist who can design, implement and teach me… See More",
			"lanes": ["ai"],
			"stacks": []
		},
		{
			"id": "1723719",
			"title": "AI Systems & Automation Specialist",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ai-systems-automation-specialist-1723719",
			"pay": "$2000-$3000 per month",
			"type": "Full Time",
			"posted": "2026-10-15 04:07:20",
			"snippet": "AI Systems & Automation Engineer — Build Our AI Workforce About the Role We are looking for a highly skilled AI Systems & Automation Engineer to help us design, build, and continuously improve an AI-powered operating system across our businesses.… See More",
			"lanes": ["ai"],
			"stacks": []
		},
		{
			"id": "1749509",
			"title": "AI Automation Developer / AI Agent Builder Needed!",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ai-automation-developer-ai-agent-builder-needed-1749509",
			"pay": "800usd/month",
			"type": "Full Time",
			"posted": "2026-10-14 12:20:36",
			"snippet": "## About Us TAD is not a normal trading education company. We are building one of the fastest growing trading education brands in the region. Our mission is simple. We want to help everyday people learn trading in a clear,… See More",
			"lanes": ["ai"],
			"stacks": []
		},
		{
			"id": "1561771",
			"title": "Elementor, SEO, Schema, Go High Level Website Builder",
			"url": "https://www.onlinejobs.ph/jobseekers/job/elementor-seo-schema-go-high-level-website-builder-1561771",
			"pay": "400/month",
			"type": "Part Time",
			"posted": "2026-10-12 21:29:50",
			"snippet": "I am looking for someone with experience in: Elementor (WordPress) SEO implementation, tracking and reporting Schema markup GoHighLevel website builder and funnels You must be able to work during business hours CST and show your progress This is not a… See More",
			"lanes": ["ghl"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1745905",
			"title": "GHL Specialist – CRM, Automation & Workflow Expert",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ghl-specialist-crm-automation-workflow-expert-1745905",
			"pay": "",
			"type": "Any",
			"posted": "2026-10-08 08:30:36",
			"snippet": "We are looking for an experienced GoHighLevel (GHL) Specialist to join our team and help build, manage, troubleshoot, and optimize GHL systems for our clients. This is NOT a basic VA role. We are looking for someone who has real,… See More",
			"lanes": ["ghl"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1745823",
			"title": "Go High Level Expert",
			"url": "https://www.onlinejobs.ph/jobseekers/job/go-high-level-expert-1745823",
			"pay": "$150 - $400",
			"type": "Any",
			"posted": "2026-10-08 05:38:02",
			"snippet": "RigStar Media is hiring a GoHighLevel specialist to connect Zeffy (donation platform) to GoHighLevel using Zapier: contacts, tags, donation data, pipeline, and automated thank-you follow-up. This takes about 15 minutes. The scenario questions carry the most weight, so answer them… See More",
			"lanes": ["ghl", "ai"],
			"stacks": ["GoHighLevel", "Zapier"]
		},
		{
			"id": "1741995",
			"title": "AI Automation & Backend Developer – GoHighLevel / APIs / Spring Boot",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ai-automation-backend-developer-gohighlevel-apis-spring-boot-1741995",
			"pay": "$8/hour",
			"type": "Any",
			"posted": "2026-10-02 03:31:51",
			"snippet": "About Legacy CRM Legacy CRM is a white-labeled GoHighLevel SaaS platform built specifically for life insurance agents in the United States. We currently serve approximately 50 paying agents and are actively expanding our platform with AI-powered SMS agents, automated lead… See More",
			"lanes": ["ghl", "ai"],
			"stacks": ["GoHighLevel", "API"]
		},
		{
			"id": "1722382",
			"title": "AI Automation Specialist – Make.com / Supabase / GoHighLevel (Long-Term, Full-Time)",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ai-automation-specialist-make-com-supabase-gohighlevel-long-term-full-time-1722382",
			"pay": "$8/hour",
			"type": "Full Time",
			"posted": "2026-10-02 03:11:53",
			"snippet": "About the Company Legacy CRM is a white-labeled GoHighLevel SaaS platform built for life insurance agents in the US. We serve around 50 paying agents and are actively expanding into AI-powered tools like voice agents and automated lead follow-up. You'll… See More",
			"lanes": ["ghl", "ai"],
			"stacks": ["GoHighLevel", "Make"]
		},
		{
			"id": "1537712",
			"title": "Digital Marketing & AI Automation Specialist (GoHighLevel Expert)",
			"url": "https://www.onlinejobs.ph/jobseekers/job/digital-marketing-ai-automation-specialist-gohighlevel-expert-1537712",
			"pay": "7",
			"type": "Any",
			"posted": "2026-09-30 12:44:30",
			"snippet": "Full-Time | Remote | Long-Term Opportunity We’re building a serious marketing operation—not another agency pushing generic content. We’re looking for an experienced Digital Marketing & AI Automation Specialist who understands how to generate leads, build marketing systems, automate operations, and… See More",
			"lanes": ["ghl", "ai"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1699509",
			"title": "CRM build out and management",
			"url": "https://www.onlinejobs.ph/jobseekers/job/crm-build-out-and-management-1699509",
			"pay": "$5/hour",
			"type": "Gig",
			"posted": "2026-09-30 03:35:46",
			"snippet": "Looking for someone to build out GHL/CRM for the business, then create and manage landing pages with ads for lead generation. Must be skilled with experience in Go High Level building and management. Expect more work needed in the beginning… See More",
			"lanes": ["ghl"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1738930",
			"title": "AI Automation Developer - Claude Code, Python, Next.js, Supabase",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ai-automation-developer-claude-code-python-next-js-supabase-1738930",
			"pay": "8-15",
			"type": "Full Time",
			"posted": "2026-09-27 20:58:01",
			"snippet": "We're a real estate brokerage and investment team on Long Island, New York, and we build our own software with Claude Code. Today that's nearly 30 internal web apps plus a fleet of automations: an AI phone receptionist, SMS systems,… See More",
			"lanes": ["ai"],
			"stacks": ["Claude", "Python"]
		},
		{
			"id": "1738744",
			"title": "Hiring: AI Automation & GoHighLevel Developer",
			"url": "https://www.onlinejobs.ph/jobseekers/job/hiring-ai-automation-gohighlevel-developer-1738744",
			"pay": "$10 - $12 a hour",
			"type": "Part Time",
			"posted": "2026-09-27 05:30:48",
			"snippet": "Location: Remote Starting Schedule: Approximately 10 hours per week Starting Pay: $12/hour Growth Opportunity: Hours will increase as Scale AI Pros continues to add clients and expand projects Potential Path: Part-Time → Expanded Part-Time → Full-Time ________________________________________ About Scale AI… See More",
			"lanes": ["ghl", "ai"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1402138",
			"title": "Go high Level Expert",
			"url": "https://www.onlinejobs.ph/jobseekers/job/go-high-level-expert-1402138",
			"pay": "250-500",
			"type": "Gig",
			"posted": "2026-09-23 11:57:53",
			"snippet": "seeking a Go High-Level expert who can confidently build and optimize automation systems for client funnels. Our team works with high-performing entrepreneurs, coaches, and brands – and we need someone who knows how to bring workflows to life. What You’ll… See More",
			"lanes": ["ghl"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1734220",
			"title": "Hermes AI Developer Needed to Build a Real-World “Jarvis”",
			"url": "https://www.onlinejobs.ph/jobseekers/job/hermes-ai-developer-needed-to-build-a-real-world-jarvis-1734220",
			"pay": "$5 per hour",
			"type": "Gig",
			"posted": "2026-09-20 07:40:51",
			"snippet": "Hermes AI Developer Needed to Build a Real-World “Jarvis” I’m looking for an experienced developer who knows how to use **Hermes Agent** to help me build a real-world version of Jarvis—the intelligent AI assistant from the movies. This is not… See More",
			"lanes": ["ai"],
			"stacks": []
		},
		{
			"id": "1202189",
			"title": "GHL Automation Expert",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ghl-automation-expert-1202189",
			"pay": "$4/hr",
			"type": "Part Time",
			"posted": "2026-09-18 19:03:52",
			"snippet": "Join us as a GHL Automation Expert to redefine customer engagement. You will work on automation strategy using cutting-edge Go High Level (GHL) tools. If you thrive in a fast-paced environment and excel at turning complex data into engaging customer… See More",
			"lanes": ["ghl"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1705298",
			"title": "Go High Level Expert",
			"url": "https://www.onlinejobs.ph/jobseekers/job/go-high-level-expert-1705298",
			"pay": "$8/hour, or $90/week",
			"type": "Part Time",
			"posted": "2026-09-16 04:43:05",
			"snippet": "Primary Responsibilities- Must have 7-10 years of actively working with Go High Level 15-20 hours a week GoHighLevel CRM & Marketing Automation — Core Responsibility Own and continuously optimize Toivoa Coaching Academy and Toivoa’s GoHighLevel platform as the central marketing,… See More",
			"lanes": ["ghl"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1730818",
			"title": "Senior Mobile App Developer — Voice AI / React Native",
			"url": "https://www.onlinejobs.ph/jobseekers/job/senior-mobile-app-developer-voice-ai-react-native-1730818",
			"pay": "800 per month",
			"type": "Any",
			"posted": "2026-09-15 20:08:14",
			"snippet": "Senior Mobile App Developer — Voice AI / React Native HAILU is building a modern rideshare platform and we're looking for an experienced developer to build our Customer Mobile App, including our key differentiator — the HAILU Voice AI Assistant.… See More",
			"lanes": ["ai"],
			"stacks": ["Voice AI"]
		},
		{
			"id": "1729551",
			"title": "# GoHighLevel Automation & AI Specialist",
			"url": "https://www.onlinejobs.ph/jobseekers/job/gohighlevel-automation-ai-specialist-1729551",
			"pay": "850",
			"type": "Full Time",
			"posted": "2026-09-14 06:04:09",
			"snippet": "# GoHighLevel Automation & AI Specialist ### Full-Time | Remote | Long-Term Position **Company:** KGO Nova **Schedule:** Monday–Friday **Current Hours:** 5:00 PM–1:00 AM Eastern Time -- 8 Hours/daily **Pay:** $850 USD/month, paid weekly at **$212.50 USD** **Bonuses:** Performance-based bonuses available… See More",
			"lanes": ["ghl"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1612866",
			"title": "Go highlevel Expert & Support Specialist",
			"url": "https://www.onlinejobs.ph/jobseekers/job/go-highlevel-expert-support-specialist-1612866",
			"pay": "open",
			"type": "Any",
			"posted": "2026-09-11 02:42:23",
			"snippet": "GoHighLevel CRM Builder & Automation Specialist (Systems Operator + Client-Facing) We are hiring a high-level GoHighLevel builder who can architect, automate, and optimize CRM systems that directly impact revenue. This is not a VA admin role. This is a systems… See More",
			"lanes": ["ghl"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1663590",
			"title": "Go High Level Expert",
			"url": "https://www.onlinejobs.ph/jobseekers/job/go-high-level-expert-1663590",
			"pay": "open",
			"type": "Full Time",
			"posted": "2026-09-11 02:41:58",
			"snippet": "GoHighLevel CRM Builder & Automation Specialist (Systems Operator + Client-Facing) We are hiring a high-level GoHighLevel builder who can architect, automate, and optimize CRM systems that directly impact revenue. This is not a VA admin role. This is a systems… See More",
			"lanes": ["ghl"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1664453",
			"title": "GO HIGH LEVEL PRO!!!",
			"url": "https://www.onlinejobs.ph/jobseekers/job/go-high-level-pro-1664453",
			"pay": "open",
			"type": "Full Time",
			"posted": "2026-09-11 02:41:45",
			"snippet": "# GoHighLevel (GHL) Automation & AI Specialist ### About Us Apex Agent Pro is seeking a highly skilled GoHighLevel (GHL) Automation & AI Specialist to join our growing team. This role is ideal for someone who thrives on building systems,… See More",
			"lanes": ["ghl"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1726764",
			"title": "AI Systems Builder / Automation Engineer / Full-Stack Dev",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ai-systems-builder-automation-engineer-full-stack-dev-1726764",
			"pay": "$600 STARTING WAGE",
			"type": "Part Time",
			"posted": "2026-09-09 18:29:15",
			"snippet": "# Full-Stack AI Engineer to own the ScaleSage platform Python, FastAPI, Next.js, Supabase. Remote. Part-time to start, with a written path to full-time and technical lead across the group. ## Who I am and what this is I'm Jordan, a… See More",
			"lanes": ["ai"],
			"stacks": ["Python"]
		},
		{
			"id": "1726014",
			"title": "Software Engineer, AI Efficient (n8n, APIs, Supabase), Long Term",
			"url": "https://www.onlinejobs.ph/jobseekers/job/software-engineer-ai-efficient-n8n-apis-supabase-long-term-1726014",
			"pay": "$3.50-$6.00/hour",
			"type": "Any",
			"posted": "2026-09-08 21:58:47",
			"snippet": "Read the whole post. This one has an application form at the bottom and a code word. Applications sent any other way are not read. Kliento is a US company in Buffalo, New York. We build AI systems for real… See More",
			"lanes": ["ai"],
			"stacks": ["n8n", "API"]
		},
		{
			"id": "1708327",
			"title": "n8n, ghl, vapi, retell, openclaw, lovable",
			"url": "https://www.onlinejobs.ph/jobseekers/job/n8n-ghl-vapi-retell-openclaw-lovable-1708327",
			"pay": "4",
			"type": "Any",
			"posted": "2026-09-07 08:33:03",
			"snippet": "looking for an experienced automation developer to help build and maintain sales and call-center systems. Tools: n8n GoHighLevel (GHL) Vapi / Retell AI OpenClaw APIs & Webhooks Lovable proposal generation with custom fields from ghl AI/LLM integrations Main Responsibilities: Build… See More",
			"lanes": ["ghl", "ai"],
			"stacks": [
				"GoHighLevel",
				"n8n",
				"Vapi",
				"Retell",
				"API"
			]
		},
		{
			"id": "1724386",
			"title": "Go High Level Expert",
			"url": "https://www.onlinejobs.ph/jobseekers/job/go-high-level-expert-1724386",
			"pay": "5.00",
			"type": "Any",
			"posted": "2026-09-06 01:54:18",
			"snippet": "**GoHighLevel Expert Needed** We’re seeking an experienced GoHighLevel expert to help build, optimize, and manage CRM systems and marketing automations for our agency and clients. **What we’re looking for:** * Proven experience with GoHighLevel * Strong knowledge of workflows, pipelines,… See More",
			"lanes": ["ghl"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1724219",
			"title": "GoHighLevel Specialist - Build & Run AI Automation for US Local Businesses (Full-Time, US Pacific Hours)",
			"url": "https://www.onlinejobs.ph/jobseekers/job/gohighlevel-specialist-build-run-ai-automation-for-us-local-businesses-full-time-us-pacific-hours-1724219",
			"pay": "$1,000/month",
			"type": "Full Time",
			"posted": "2026-09-05 17:14:16",
			"snippet": "We are a US marketing agency building the AI automation arm for local service businesses - kitchen & bath remodelers, roofers, sign companies, lenders. Everything runs on GoHighLevel Agency Pro. We are hiring ONE specialist to own the build and… See More",
			"lanes": ["ghl", "ai"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1723778",
			"title": "GoHighLevel Conversation AI + LC Phone Specialist — Voice AI / SMS / Human Handoff",
			"url": "https://www.onlinejobs.ph/jobseekers/job/gohighlevel-conversation-ai-lc-phone-specialist-voice-ai-sms-human-handoff-1723778",
			"pay": "20 to 45 hr",
			"type": "Gig",
			"posted": "2026-09-04 21:40:20",
			"snippet": "We are building ASC Edge VIP, a personal AI communications assistant inside GoHighLevel. The broader product, snapshot, onboarding flow, pricing plans, and Voice AI agent already exist. We are not looking for a general GHL developer, funnel builder, website person,… See More",
			"lanes": ["ghl", "ai"],
			"stacks": ["GoHighLevel", "Voice AI"]
		},
		{
			"id": "1685513",
			"title": "Voice AI Engineer - Excellent English Required",
			"url": "https://www.onlinejobs.ph/jobseekers/job/voice-ai-engineer-excellent-english-required-1685513",
			"pay": "30,000–50,000",
			"type": "Full Time",
			"posted": "2026-09-03 12:03:04",
			"snippet": "We're a startup based in the San Francisco Bay Area, building AI agents, and we're hiring a full-time, long-term AI Engineer in the Philippines — and we'll train you. You don't need prior experience with our specific tools; if you're… See More",
			"lanes": ["ai"],
			"stacks": ["Voice AI"]
		},
		{
			"id": "1698216",
			"title": "AI Voice Automation Developer",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ai-voice-automation-developer-1698216",
			"pay": "$7.00 per hour",
			"type": "Part Time",
			"posted": "2026-08-28 01:27:49",
			"snippet": "We are looking for an experienced Automation & AI Voice Developer in the Philippines to build, optimize, and maintain automated voice AI workflows. You will focus on configuring Retell AI agents and building complex integration scenarios using Make.com (Integromat) to… See More",
			"lanes": ["ai"],
			"stacks": [
				"Make",
				"Retell",
				"Voice AI"
			]
		},
		{
			"id": "1511434",
			"title": "AI Automation Engineer (Retell AI / n8n / API Integrations)",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ai-automation-engineer-retell-ai-n8n-api-integrations-1511434",
			"pay": "4.00/hour",
			"type": "Part Time",
			"posted": "2026-08-27 21:33:57",
			"snippet": "I’m building a powerful AI call-answering system for home-service businesses (plumbers, HVAC, roofers, electricians). I need an automation-focused engineer who can help build the technical foundation using tools like: Retell AI Vapi / ElevenLabs n8n automations Go High Level APIs,… See More",
			"lanes": ["ghl", "ai"],
			"stacks": [
				"GoHighLevel",
				"n8n",
				"Vapi",
				"Retell",
				"API"
			]
		},
		{
			"id": "1714625",
			"title": "oice AI Engineer — Vapi / Retell (Dental Appointment Booking)",
			"url": "https://www.onlinejobs.ph/jobseekers/job/oice-ai-engineer-vapi-retell-dental-appointment-booking-1714625",
			"pay": "800",
			"type": "Any",
			"posted": "2026-08-22 18:38:06",
			"snippet": "Build, configure and deploy inbound and outbound voice agents on Vapi and/or Retell Write and maintain custom tools / functions the agent calls mid-conversation (check availability, create appointment, reschedule, cancel, look up patient, take a message) Integrate with practice management… See More",
			"lanes": ["ai"],
			"stacks": ["Vapi", "Retell"]
		},
		{
			"id": "1714212",
			"title": "AI Automation Specialist",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ai-automation-specialist-1714212",
			"pay": "$1280",
			"type": "Any",
			"posted": "2026-08-21 23:29:20",
			"snippet": "AI Automation Specialist Work Setup: Remote, Full-time hours — 3-month contract (with potential to extend and grow into a lead role) Pay: Monthly contract salary, $960–$1,280/month (equivalent to ~$6–$8/hour, based on ~160 hours/month), depending on experience. Strong builders at the… See More",
			"lanes": ["ai"],
			"stacks": []
		},
		{
			"id": "1708250",
			"title": "AI Implementation & Automation Specialist",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ai-implementation-automation-specialist-1708250",
			"pay": "offer salary best will be picked",
			"type": "Any",
			"posted": "2026-08-13 11:48:50",
			"snippet": "AI Implementation & Automation Specialist Position: AI Implementation & Automation Specialist Work Arrangement: Remote Employment Type: Full-Time / Contract Department: Technology & AI Automation Start Date: ASAP Position Overview We are seeking a highly skilled and creative AI Implementation &… See More",
			"lanes": ["ai"],
			"stacks": []
		},
		{
			"id": "1652190",
			"title": "GHL Specialist – Automation specialist",
			"url": "https://www.onlinejobs.ph/jobseekers/job/ghl-specialist-automation-specialist-1652190",
			"pay": "based on experience",
			"type": "Any",
			"posted": "2026-08-12 04:47:12",
			"snippet": "Role Overview: We’re looking for a GHL power user who can build, deploy, and optimize automation flows inside GoHighLevel. You’ll bridge the gap between conversational AI and GHL’s automation suite (campaigns, pipelines, triggers). Key Responsibilities: Design and implement AI voice… See More",
			"lanes": ["ghl", "ai"],
			"stacks": ["GoHighLevel"]
		},
		{
			"id": "1703238",
			"title": "Senior AI Automation & Marketing Intelligence Specialist (Claude/ Meta marketing / Ads Analytics/ Make)",
			"url": "https://www.onlinejobs.ph/jobseekers/job/senior-ai-automation-marketing-intelligence-specialist-claude-meta-marketing-ads-analytics-make-1703238",
			"pay": "?75,600 - ?92,400",
			"type": "Part Time",
			"posted": "2026-08-05 21:01:32",
			"snippet": "#Senior AI Automation & Marketing Intelligence Specialist **Australian Physiotherapy Group | Part-Time | Long-Term** * **Hours:** 25–30 hours per week * **Salary:** PHP 70,000–90,000 per month * **Location:** Remote—Philippines * **Schedule:** Flexible, with consistent Adelaide business-hours overlap ## The Opportunity… See More",
			"lanes": ["ai"],
			"stacks": ["Claude"]
		}
	]
};
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var rescanJobs = createServerFn({ method: "POST" }).handler(createSsrRpc("19fb3e991a7f15eb292e34261c21e4b1ab397883c77376bd5f5f772155400363"));
var board = board_default;
var LANES = [
	{
		id: "all",
		label: "All builds"
	},
	{
		id: "ghl",
		label: "GHL builds"
	},
	{
		id: "ai",
		label: "AI automation"
	},
	{
		id: "both",
		label: "Both"
	}
];
var TYPES = [
	"All types",
	"Full Time",
	"Part Time",
	"Gig",
	"Any"
];
var STACKS = [
	"Any stack",
	"GoHighLevel",
	"n8n",
	"Make",
	"Zapier",
	"Voice AI"
];
function tidySnippet(value) {
	return value.replace(/\s*see more\s*$/i, "").trim();
}
function tidyTitle(title) {
	return title.replace(/^#\s*/, "").replace(/^job title:\s*/i, "").replace(/^oice AI/i, "Voice AI");
}
function formatPosted(value) {
	const day = value.slice(0, 10);
	const parsed = parse(day, "yyyy-MM-dd", new Date(2026, 0, 1));
	if (Number.isNaN(parsed.getTime())) return value;
	return format(parsed, "d MMM yyyy");
}
function laneLabel(lane) {
	return lane === "ghl" ? "GHL build" : "AI automation";
}
function why(job) {
	if (job.lanes.length === 2) return "GoHighLevel system build that also ships AI automation.";
	if (job.lanes.includes("ghl")) return "GoHighLevel build — funnels, workflows, snapshots, or sub-accounts.";
	return "AI automation build — agents, voice, or workflow systems.";
}
function mergeJobs(current, incoming) {
	const map = new Map(current.map((job) => [job.id, job]));
	for (const job of incoming) map.set(job.id, job);
	return [...map.values()].sort((a, b) => b.posted.localeCompare(a.posted));
}
function JobBoard() {
	const [jobs, setJobs] = (0, import_react.useState)(board.jobs);
	const [query, setQuery] = (0, import_react.useState)("");
	const [lane, setLane] = (0, import_react.useState)("all");
	const [type, setType] = (0, import_react.useState)("All types");
	const [stack, setStack] = (0, import_react.useState)("Any stack");
	const [sort, setSort] = (0, import_react.useState)("newest");
	const [selectedId, setSelectedId] = (0, import_react.useState)(null);
	const [scanning, setScanning] = (0, import_react.useState)(false);
	const [note, setNote] = (0, import_react.useState)(`Saved scan of ${board.source}, 9 Nov 2026. ${board.read} posts read, ${board.kept} kept.`);
	const visible = (0, import_react.useMemo)(() => {
		const needle = query.trim().toLowerCase();
		const next = jobs.filter((job) => {
			if (lane === "both" && job.lanes.length < 2) return false;
			if (lane === "ghl" && !job.lanes.includes("ghl")) return false;
			if (lane === "ai" && !job.lanes.includes("ai")) return false;
			if (type !== "All types" && job.type !== type) return false;
			if (stack !== "Any stack" && !job.stacks.includes(stack)) return false;
			if (!needle) return true;
			return `${job.title} ${job.snippet} ${job.stacks.join(" ")} ${job.pay}`.toLowerCase().includes(needle);
		});
		next.sort((a, b) => {
			if (sort === "pay") return payRank(b.pay) - payRank(a.pay);
			return b.posted.localeCompare(a.posted);
		});
		return next;
	}, [
		jobs,
		query,
		lane,
		type,
		stack,
		sort
	]);
	const selected = visible.find((job) => job.id === selectedId) ?? null;
	const stripped = board.stripped.coldCallDataEntry + board.stripped.basic;
	async function rescan() {
		setScanning(true);
		try {
			const result = await rescanJobs();
			if (result.jobs.length) setJobs((current) => mergeJobs(current, result.jobs));
			setNote(result.message);
		} catch {
			setNote("Live scan failed. The saved OnlineJobs.ph pull is still here.");
		} finally {
			setScanning(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "min-h-screen bg-bg text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex w-full min-w-0 max-w-6xl flex-col gap-6 px-4 py-6 sm:px-6 sm:py-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex flex-col gap-5 border-b border-border pb-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-start justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 flex h-11 w-11 items-center justify-center rounded-lg bg-primary text-primary-fg",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radar, {
										className: "h-5 w-5",
										"aria-hidden": true
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-mono text-xs tracking-widest text-primary uppercase",
										children: "OnlineJobs.ph"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
										className: "text-3xl font-semibold tracking-tight",
										children: "Forge"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 max-w-xl text-sm leading-relaxed text-muted",
										children: "GoHighLevel builds and AI automation only. Cold calling, data entry, appointment setting, and basic VA work never make this list."
									})
								] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: rescan,
								disabled: scanning,
								className: "inline-flex h-11 items-center gap-2 rounded-lg bg-primary px-4 text-sm font-semibold text-primary-fg disabled:opacity-60",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
									className: `h-4 w-4 ${scanning ? "animate-spin" : ""}`,
									"aria-hidden": true
								}), scanning ? "Scanning" : "Rescan"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "grid grid-cols-2 gap-3 sm:grid-cols-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "Posts read",
									value: String(board.read)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "Builder roles",
									value: String(jobs.length)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "Cold call / data / VA",
									value: String(stripped),
									hint: "stripped"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "Off the lane",
									value: String(board.stripped.offLane),
									hint: "not a build"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs leading-relaxed text-muted",
							children: note
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "relative block",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "sr-only",
									children: "Search roles"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
									className: "pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted",
									"aria-hidden": true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: query,
									onChange: (event) => setQuery(event.target.value),
									placeholder: "Search title, stack, or pay",
									className: "h-11 w-full rounded-lg border border-border bg-surface pr-3 pl-10 text-sm text-fg outline-none placeholder:text-muted focus:border-primary"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: LANES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
								active: lane === item.id,
								onClick: () => setLane(item.id),
								label: item.label
							}, item.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [
								TYPES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
									active: type === item,
									onClick: () => setType(item),
									label: item
								}, item)),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
									active: sort === "newest",
									onClick: () => setSort("newest"),
									label: "Newest"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
									active: sort === "pay",
									onClick: () => setSort("pay"),
									label: "Higher posted pay"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: STACKS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
								active: stack === item,
								onClick: () => setStack(item),
								label: item
							}, item))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-mono text-xs text-muted",
							children: [
								"Showing ",
								visible.length,
								" of ",
								jobs.length
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid items-start gap-4 lg:grid-cols-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "flex flex-col gap-3 lg:col-span-2",
						children: visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "rounded-lg border border-border bg-surface px-4 py-8 text-sm text-muted",
							children: "Nothing in this cut. Clear a filter or rescan OnlineJobs.ph."
						}) : visible.map((job) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setSelectedId((current) => current === job.id ? null : job.id),
							"aria-expanded": selected === job,
							className: `lift w-full rounded-lg border px-4 py-4 text-left ${selected?.id === job.id ? "border-primary bg-surface-2" : "border-border bg-surface"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center gap-2",
									children: [
										job.lanes.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LaneTag, { lane: item }, item)),
										job.type ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-mono text-xs text-muted",
											children: job.type
										}) : null,
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "ml-auto font-mono text-xs text-muted",
											children: formatPosted(job.posted)
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-2 text-lg leading-snug font-semibold",
									children: tidyTitle(job.title)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 font-mono text-sm text-primary",
									children: job.pay || "Pay not listed"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 line-clamp-3 text-sm leading-relaxed text-muted",
									children: tidySnippet(job.snippet) || "Open the original post for the full brief."
								}),
								job.stacks.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 font-mono text-xs text-muted",
									children: job.stacks.join(" · ")
								}) : null
							]
						}), selected?.id === job.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "lg:hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Detail, { job })
						}) : null] }) }, job.id))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
						className: "hidden lg:sticky lg:top-4 lg:block",
						children: selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Detail, { job: selected }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rounded-lg border border-border bg-surface px-4 py-6 text-sm leading-relaxed text-muted",
							children: "Select a role. The brief is the OnlineJobs.ph snippet. Apply on the original post — Forge does not message employers."
						})
					})]
				})
			]
		})
	});
}
function Stat({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-border bg-surface px-3 py-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
				className: "font-mono text-xs tracking-wide text-muted uppercase",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
				className: "mt-1 text-2xl font-semibold tracking-tight",
				children: value
			}),
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-xs text-muted",
				children: hint
			}) : null
		]
	});
}
function Chip({ active, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		"aria-pressed": active,
		className: `h-11 rounded-lg border px-3 text-sm ${active ? "border-primary bg-primary text-primary-fg" : "border-border bg-surface text-fg"}`,
		children: label
	});
}
function LaneTag({ lane }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `rounded-md px-2 py-1 font-mono text-xs ${lane === "ghl" ? "bg-primary text-primary-fg" : "border border-primary text-primary"}`,
		children: laneLabel(lane)
	});
}
function Detail({ job }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-2 rounded-lg border border-border bg-surface-2 p-4 lg:mt-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-xs tracking-widest text-primary uppercase",
				children: "Why it is here"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm leading-relaxed",
				children: why(job)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm leading-relaxed text-muted",
				children: tidySnippet(job.snippet) || "The search card did not include a description."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
				href: job.url,
				target: "_blank",
				rel: "noreferrer",
				className: "mt-4 inline-flex h-11 items-center gap-2 rounded-lg bg-primary px-4 text-sm font-semibold text-primary-fg",
				children: ["Open on OnlineJobs.ph", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
					className: "h-4 w-4",
					"aria-hidden": true
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 font-mono text-xs text-muted",
				children: "A jobseeker login is required to apply. Pay is copied from the post."
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(JobBoard, {});
}
//#endregion
export { Home as component };
