import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { r as screenListing, t as parseSearchHtml } from "./filter-BeQQAM0I.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/scan--TtY0CPW.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var QUERIES = [
	"https://www.onlinejobs.ph/jobseekers/jobsearch?jobkeyword=gohighlevel&isFromJobsearchForm=1",
	"https://www.onlinejobs.ph/jobseekers/jobsearch/30?jobkeyword=gohighlevel&isFromJobsearchForm=1",
	"https://www.onlinejobs.ph/jobseekers/jobsearch?jobkeyword=n8n&isFromJobsearchForm=1",
	"https://www.onlinejobs.ph/jobseekers/jobsearch?jobkeyword=AI%20automation&isFromJobsearchForm=1",
	"https://www.onlinejobs.ph/jobseekers/jobsearch?skill_tags=24220&isFromJobsearchForm=1"
];
async function fetchPage(url) {
	const response = await fetch(url, {
		headers: {
			"user-agent": "Mozilla/5.0 (compatible; ForgeJobRadar/1.0; +https://www.onlinejobs.ph/)",
			accept: "text/html"
		},
		signal: AbortSignal.timeout(12e3)
	});
	if (!response.ok) throw new Error(`OnlineJobs.ph returned ${response.status}`);
	return response.text();
}
var rescanJobs_createServerFn_handler = createServerRpc({
	id: "19fb3e991a7f15eb292e34261c21e4b1ab397883c77376bd5f5f772155400363",
	name: "rescanJobs",
	filename: "src/lib/jobs/scan.ts"
}, (opts) => rescanJobs.__executeServer(opts));
var rescanJobs = createServerFn({ method: "POST" }).handler(rescanJobs_createServerFn_handler, async () => {
	const byId = /* @__PURE__ */ new Map();
	let read = 0;
	let failures = 0;
	for (const url of QUERIES) try {
		const html = await fetchPage(url);
		const cards = parseSearchHtml(html);
		read += cards.length;
		for (const card of cards) {
			const screened = screenListing(card);
			if (screened.job) byId.set(screened.job.id, screened.job);
		}
	} catch {
		failures += 1;
	}
	const jobs = [...byId.values()].sort((a, b) => b.posted.localeCompare(a.posted));
	if (!jobs.length && failures === QUERIES.length) return {
		ok: false,
		scannedAt: (/* @__PURE__ */ new Date()).toISOString(),
		read,
		kept: 0,
		jobs: [],
		message: "OnlineJobs.ph did not respond. The saved scan is still on screen."
	};
	return {
		ok: true,
		scannedAt: (/* @__PURE__ */ new Date()).toISOString(),
		read,
		kept: jobs.length,
		jobs,
		message: failures > 0 ? `Live pass read ${read} posts. ${failures} search page${failures === 1 ? "" : "s"} failed.` : `Live pass read ${read} posts and kept ${jobs.length} builder roles.`
	};
});
//#endregion
export { rescanJobs_createServerFn_handler };
