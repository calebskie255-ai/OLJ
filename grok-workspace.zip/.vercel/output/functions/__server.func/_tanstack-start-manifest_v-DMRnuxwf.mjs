//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DMRnuxwf.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CX4GcWN-.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CX4GcWN-.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-D0mkN4qV.js"]
	}
} });
//#endregion
export { tsrStartManifest };
